
add the following lines to python.properties so that Ctrl+4 runs a script
and traces the contents of local vars if any unhandled exception occurs
if python is not in the system PATH, provide the path to python

command.name.4.*.py=print error context
command.4.*.py=python c:\path\to\python_print_vars.py "$(FilePath)"

