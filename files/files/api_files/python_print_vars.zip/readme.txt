
add the following lines to python.properties so that Ctrl+4 runs a script
if any unhandled exception occurs,
we'll show the contents of local variables,
which can be useful for debugging

command.name.4.*.py=print error context
command.4.*.py=c:\python37\python c:\path\to\python_print_vars.py "$(FilePath)"

