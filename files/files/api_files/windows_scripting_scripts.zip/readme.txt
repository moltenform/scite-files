# Using SciTE for Windows Scripting

By Alex K. Angelopoulos. (Copied from remotenetworktechnology.com which no longer exists.)

### Why Use SciTE For Windows Scripting?

SciTE features:

    * fully customizable syntax highlighting (of course).
    * text folding for structures, procedures, and classes.
    * a customizable tools menu which supports document-sensitive configuration and a good set of support macros
    * language-specific highlighting and folding for structured documents such as WSF and WSC files.
    * configurable execution subsystems for tools - you can shell execute, run a console command internally and capture output, or run it externally, for example.
    * line numbering, with configurable properties
    * a host of capabilities you won't value until you see them in action.  The richness of the config files can look overwhelming at first, but the flat Unixish structure makes it easy to home in on what you want to change, and the SciTEDoc.html file accompanying it explains in detail what the settings mean.

### WSH-Related SciTE Properties Files

I make no claim that these are in any way complete at this point; I wrote them for my own use after about 3 days experience with SciTE.  I am providing them as a potential starting point for other people using SciTE.

<font size="3"><a href="https://raw.githubusercontent.com/moltenjs/scite-files/master/files/files/api_files/windows_scripting_scripts.zip">Download files mentioned in this article</a></font>

* SciTE/vbscript.properties

    * Extended keywords for VBScript.

* SciTE/vbscript_abbrev.properties

    * Clip text abbreviations for SciTE; includes my most frequently reused functions, subroutines, and code blocks.

* SciTE/ws.properties

    * A preliminary version of a parser for embedded highlighting of WSF and WSC files.

### SciTE Helper Scripts

<font size="3"><a href="https://raw.githubusercontent.com/moltenjs/scite-files/master/files/files/api_files/windows_scripting_scripts.zip">Download files mentioned in this article</a></font>

* SciTE/Scitevbp.vbs.txt

    * Works via drag-and-drop or as a tool.  Given a VBP file as a target, will parse it for all member files and load them in SciTE. In SciTE, if using an opened VBP as the target set the command target to something like

    * cscript <path-to-Scitevbp.vbs>  "$(FilePath)"

* SciTE/WordCheck.vbs.txt

    * A script which allows running spell checks on documents in SciTE using the Word Spelling and Grammar checker.

    * Wscript <path-to-Wordcheck.vbs>  "$(FilePath)"

* SciTE/mskb.vbs.txt

    * Script to retrieve the raw text from an MSKB article; can be used by highlighting an embedded Q article number in the active document. This will "clean"  a Q-number, removing everything but the actual numbers from the string first, so if you have an old URL with embedded slashes or grab white space or characters around the number it doesn't matter.   For in-SciTE capture, use a command like this:

    * cscript <path-to-Scitevbp.vbs>  $(CurrentSelection)

    * and set the subsystem to 0.

* SciTE/GetXml.vbs.txt

    * Similar to the above, but will retrieve the source HTML of a selected URL via the Microsoft.XMLHTTP object.  As above, for in-SciTE capture, use a command like this:

    * cscript <path-to-Scitevbp.vbs>  $(CurrentSelection)

    * and set the subsystem to 0.

* SciTE/ChangeScriptingEditor.vbs.txt

    * This is an adaptation of Jim Warrington's script for modifying the default Windows editor for scripts.  It has been customized to point to my copy of SciTE; you will need to edit the embedded path to use this, but it definitely speeds up the process of setting default editors as you choose.


(Saved from http://dev.remotenetworktechnology.com/SciTE/index.htm )
Scripts by Alex K. Angelopoulos


Ben F:
To use a .properties file, say x.properties for example, move the file into the SciTE directory,
and open Scite. From Options menu click on SciTEGlobal.properties.
Search in this file for 'import all the lang' and you will see a list like
import ada
import asm.
Add a line for 
import x
and save your changes.

Rename the .vbs.txt files to .vbs to use them.

