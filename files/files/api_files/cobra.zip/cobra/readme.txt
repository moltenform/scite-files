(
see http://cobra-language.com/trac/cobra/wiki/SciTE
for more information, although its installation instructions are out of date as they refer to an old version of SciTE.
in the modern version of SciTE, by default, simply placing the .properties files into the same directory as SciTE will be sufficient to install
)

