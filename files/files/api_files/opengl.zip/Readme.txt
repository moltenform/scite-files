[2002/03/15]
This maybe is the full implementaton of the OpenGL 1.2 API.
It includes opengl, glu, and glaux.
I've made my best effort for parsing the include files, so they can work.
Any comments are welcome.
Renato Moscoso [rmoscoso@geotel.com.pe]
