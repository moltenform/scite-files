

Written by Steve Donovan, 2004

Compiles to a .dll that can be used in lua to have a prettier 'exec' that doesn't open a window.

