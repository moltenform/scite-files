#define IDC_PROMPTTEXT     10
#define IDC_EDITTEXT       11
