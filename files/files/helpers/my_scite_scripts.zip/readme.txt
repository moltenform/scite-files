some lua scripts from myScite
https://github.com/arjunae/myScite
