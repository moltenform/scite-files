function html_unentities()

  local entities = {
    nbsp = '�' ,
    iexcl = '�' ,
    cent = '�' ,
    pound = '�' ,
    curren = '�' ,
    yen = '�' ,
    brvbar = '�' ,
    sect = '�' ,
    uml = '�' ,
    copy = '�' ,
    ordf = '�' ,
    laquo = '�' ,
    ['not'] = '�' ,
    shy = '�' ,
    reg = '�' ,
    macr = '�' ,
    ['deg'] = '�' ,
    plusmn = '�' ,
    sup2 = '�' ,
    sup3 = '�' ,
    acute = '�' ,
    micro = '�' ,
    para = '�' ,
    middot = '�' ,
    cedil = '�' ,
    sup1 = '�' ,
    ordm = '�' ,
    raquo = '�' ,
    frac14 = '�' ,
    frac12 = '�' ,
    frac34 = '�' ,
    iquest = '�' ,
    Agrave = '�' ,
    Aacute = '�' ,
    Acirc = '�' ,
    Atilde = '�' ,
    Auml = '�' ,
    Aring = '�' ,
    AElig = '�' ,
    Ccedil = '�' ,
    Egrave = '�' ,
    Eacute = '�' ,
    Ecirc = '�' ,
    Euml = '�' ,
    Igrave = '�' ,
    Iacute = '�' ,
    Icirc = '�' ,
    Iuml = '�' ,
    ETH = '�' ,
    Ntilde = '�' ,
    Ograve = '�' ,
    Oacute = '�' ,
    Ocirc = '�' ,
    Otilde = '�' ,
    Ouml = '�' ,
    times = '�' ,
    Oslash = '�' ,
    Ugrave = '�' ,
    Uacute = '�' ,
    Ucirc = '�' ,
    Uuml = '�' ,
    Yacute = '�' ,
    THORN = '�' ,
    szlig = '�' ,
    agrave = '�' ,
    aacute = '�' ,
    acirc = '�' ,
    atilde = '�' ,
    auml = '�' ,
    aring = '�' ,
    aelig = '�' ,
    ccedil = '�' ,
    egrave = '�' ,
    eacute = '�' ,
    ecirc = '�' ,
    euml = '�' ,
    igrave = '�' ,
    iacute = '�' ,
    icirc = '�' ,
    iuml = '�' ,
    eth = '�' ,
    ntilde = '�' ,
    ograve = '�' ,
    oacute = '�' ,
    ocirc = '�' ,
    otilde = '�' ,
    ouml = '�' ,
    divide = '�' ,
    oslash = '�' ,
    ugrave = '�' ,
    uacute = '�' ,
    ucirc = '�' ,
    uuml = '�' ,
    yacute = '�' ,
    thorn = '�' ,
    yuml = '�' ,
    quot = '"' ,
    lt = '<' ,
    gt = '>' ,
    amp = '' 
  }

  editor:ReplaceSel(string.gsub(editor:GetSelText(), "&%a+;",
    function (entity)
      return entities[string.sub(entity, 2, -2)] or entity
    end)
  )
  
end

/*
     FILE ARCHIVED ON 13:04:18 Sep 19, 2014 AND RETRIEVED FROM THE
     INTERNET ARCHIVE ON 01:15:53 Jul 03, 2018.
     JAVASCRIPT APPENDED BY WAYBACK MACHINE, COPYRIGHT INTERNET ARCHIVE.

     ALL OTHER CONTENT MAY ALSO BE PROTECTED BY COPYRIGHT (17 U.S.C.
     SECTION 108(a)(3)).
*/
/*
playback timings (ms):
  LoadShardBlock: 43.722 (3)
  esindex: 0.006
  captures_list: 57.77
  CDXLines.iter: 10.392 (3)
  PetaboxLoader3.datanode: 41.2 (4)
  exclusion.robots: 0.19
  exclusion.robots.policy: 0.18
  RedisCDXSource: 0.712
  PetaboxLoader3.resolve: 665.301
  load_resource: 678.472
*/