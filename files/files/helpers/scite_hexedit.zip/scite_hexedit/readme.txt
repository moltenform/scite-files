these are lua scripts copied from 
the scite-ru project, which are useful for 
adding features to SciTE.

note that unless you are using scite-ru's event manager,
you will probably have to 
1) set up extman
(see https://github.com/moltenform/scite-files/blob/master/files/helpers.md)
2)
replace all occurances of
AddEventHandler('OnOpen', ...)
with
scite_OnOpen(...)

AddEventHandler('OnSwitchFile', ...)
with
scite_OnSwitchFile(...)
and so on

Some of these scripts may also have dependencies on
a) shell.dll
b) scite_other dll
c) gui.dll
or
d) hta communication between scite and activex
these can be found as part of Scite-ru,
https://bitbucket.org/scite-ru/scite-ru.bitbucket.org/wiki/Home







