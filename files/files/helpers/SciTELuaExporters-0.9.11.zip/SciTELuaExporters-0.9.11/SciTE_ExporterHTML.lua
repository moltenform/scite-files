-----------------------------------------------------------------------
-- HTML exporter in Lua for SciTE
-- Version 0.9.7, 20070805
--
-- Adapted from SciTE sources (scite/src/Exporters.cxx CVS 20040723)
-- by Kein-Hong Man <khman@users.sf.net> (This is a straightforward
-- conversion and so I decline to claim it as my own.)
--
-- Copyright 1998-2007 by Neil Hodgson <neilh@scintilla.org>
-- All Rights Reserved
--
-- Permission to use, copy, modify, and distribute this software and
-- its documentation for any purpose and without fee is hereby granted,
-- provided that the above copyright notice appear in all copies and
-- that both that copyright notice and this permission notice appear in
-- supporting documentation.
--
-- NEIL HODGSON DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
-- INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN
-- NO EVENT SHALL NEIL HODGSON BE LIABLE FOR ANY SPECIAL, INDIRECT OR
-- CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
-- OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
-- NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
-- WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
--
-----------------------------------------------------------------------
-- USAGE
--
-- * Please see SciTELuaExporters.html for notes on how to get this
--   exporter up and running.
-- * Requires SciTE_ExportBase.lua to be loaded first.
-- * Has been tested casually with these lexers: lua, cpp, props,
--   and basic text giving byte-for-byte identical output.
-- * Monospace support has been removed, tracking the change in
--   Exporters.cxx. If you want it, use SciTE_ExporterHTMLPlus.lua.
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- a simple check to alert of namespace collision, but allows different
-- files to define their own functions in the exporters table
-----------------------------------------------------------------------
if exporters then
  if exporters.SaveToHTML then
    error("SciTE_ExporterHTML: exporters.SaveToHTML already defined")
  end
else
  exporters = {}
end

-----------------------------------------------------------------------
-- exporters:SaveToHTML
--
-- Exports the document in the current window to a HTML format file.
--
-----------------------------------------------------------------------
function exporters:SaveToHTML()
  local selBeg, selEnd = exportutil.GetSelPos()
  local HTMLDefaultTabSize = 4

  -- helper functions to take care of flag bit/data reads
  -- note: SC_FOLDLEVELNUMBERMASK mask must have all ones!!
  local function foldlevel(raw)
    return raw % (SC_FOLDLEVELNUMBERMASK + 1) - SC_FOLDLEVELBASE
  end
  -- returns SC_FOLDLEVELHEADERFLAG flag in boolean
  -- note: SC_FOLDLEVELHEADERFLAG must have a single bit set
  local function foldheaderflag(lvl)
    local mask = SC_FOLDLEVELHEADERFLAG * 2 - 1
    return lvl % mask >= SC_FOLDLEVELHEADERFLAG
  end

  editor:Colourise(0, -1)
  local tabSize = tonumber(props["tabsize"])
  if not tabSize or tabSize == 0 then
    tabSize = HTMLDefaultTabSize
  end

  local wysiwyg = exportutil.propbool("export.html.wysiwyg", 1)
  local tabs = exportutil.propbool("export.html.tabs")
  local folding = exportutil.propbool("export.html.folding")
  local onlyStylesUsed = exportutil.propbool("export.html.styleused")
  local titleFullPath = exportutil.propbool("export.html.title.fullpath")

  -- local lengthDoc = editor.Length

  local styleIsUsed = {}
  if onlyStylesUsed then
    -- check the used styles
    for i = selBeg, selEnd - 1 do
      styleIsUsed[exportutil.StyleAt(i)] = true
    end
  else
    for i = 0, exportutil.STYLE_MAX do
      styleIsUsed[i] = true
    end
  end
  styleIsUsed[exportutil.STYLE_DEFAULT] = true

  local saveName = exportutil.exportfile(props["FileDir"], props["FileName"], "html")
  local fp = io.open(saveName, "wt")
  if not fp then
    error("exporters:SaveToHTML: could not save file \""..saveName.."\"")
  end
  if exportutil.VERBOSE ~= 0 then
    _ALERT("\nExporting to HTML, filepath: "..saveName)
  end

  fp:write("<!DOCTYPE html  PUBLIC \"-//W3C//DTD XHTML 1.0 Transitional//EN\" \"DTD/xhtml1-strict.dtd\">\n",
           "<html xmlns=\"http://www.w3.org/1999/xhtml\">\n",
           "<head>\n")
  if titleFullPath then
    fp:write("<title>", props["FilePath"], "</title>\n")
  else
    fp:write("<title>", props["FileNameExt"], "</title>\n")
  end

  -- Probably not used by robots, but making a little advertisement for those looking
  -- at the source code doesn't hurt...
  fp:write("<meta name=\"GENERATOR\" content=\"SciTE - www.Scintilla.org\" />\n")

  if folding then
    fp:write("<script language=\"JavaScript\" type=\"text/javascript\">\n",
             "<!--\n",
             "function toggle(thisid) {\n",
             "var thislayer=document.getElementById(thisid);\n",
             "if (thislayer.style.display == 'none') {\n",
             " thislayer.style.display='block';\n",
             "} else {\n",
             " thislayer.style.display='none';\n",
             "}\n",
             "}\n",
             "//-->\n",
             "</script>\n")
  end

  fp:write("<style type=\"text/css\">\n")

  local bgColour = nil
  stylemgr:setlexer(editor.Lexer)
  for istyle = 0, exportutil.STYLE_MAX do
    if istyle > STYLE_DEFAULT and istyle <= STYLE_LASTPREDEFINED then
      -- continue
    else
      if styleIsUsed[istyle] then
        local sd = stylemgr:locate(istyle)
        if sd.specified ~= "" then
          if istyle == STYLE_DEFAULT then
            fp:write("span {\n")
          else
            fp:write(".S", istyle, " {\n")
          end
          if sd.italics then
            fp:write("\tfont-style: italic;\n")
          end
          if sd.bold then
            fp:write("\tfont-weight: bold;\n")
          end
          if wysiwyg and string.match(sd.specified, "font") then
            fp:write("\tfont-family: '"..sd.font.."';\n")
          end
          if sd.fore then
            fp:write("\tcolor: ", stylemgr:hexstr(sd.fore), ";\n")
          elseif istyle == STYLE_DEFAULT then
            fp:write("\tcolor: #000000;\n")
          end
          if sd.back then
            fp:write("\tbackground: ", stylemgr:hexstr(sd.back), ";\n")
            if istyle == STYLE_DEFAULT then
              bgColour = sd.back
            end
          end
          if wysiwyg and string.match(sd.specified, "size") then
            fp:write("\tfont-size: ", sd.size, "pt;\n")
          end
          fp:write("}\n")
        else
          styleIsUsed[istyle] = false -- No definition, it uses default style (32)
        end
      end--if styleIsUsed[istyle]
    end--if istyle
  end--for
  fp:write("</style>\n",
           "</head>\n")
  if bgColour then
    fp:write("<body bgcolor=\"", stylemgr:hexstr(bgColour), "\">\n")
  else
    fp:write("<body>\n")
  end

  local line = editor:LineFromPosition(selBeg)
  local level = foldlevel(editor.FoldLevel[line])
  local newLevel
  local styleCurrent = exportutil.StyleAt(selBeg)
  local inStyleSpan = false
  -- Global span for default attributes
  if wysiwyg then
    fp:write("<span>")
  else
    fp:write("<pre>")
  end

  if folding then
      local lvl = editor.FoldLevel[selBeg]
      level = foldlevel(lvl)

      if foldheaderflag(lvl) then
        fp:write("<span onclick=\"toggle('ln", line + 1, "')\">-</span> ")
      else
        fp:write("&nbsp; ")
      end
  end

  if styleIsUsed[styleCurrent] then
    fp:write("<span class=\"S", styleCurrent, "\">")
    inStyleSpan = true
  end
  -- Else, this style has no definition (beside default one):
  -- no span for it, except the global one

  local column = 0
  local i = selBeg
  while i < selEnd do
    local ch = exportutil.CharAt(i)
    local style = exportutil.StyleAt(i)

    if style ~= styleCurrent then
      if inStyleSpan then
        fp:write("</span>")
        inStyleSpan = false
      end
      if ch ~= "\r" and ch ~= "\n" then     -- No need of a span for the EOL
        if styleIsUsed[style] then
          fp:write("<span class=\"S", style, "\">")
          inStyleSpan = true
        end
        styleCurrent = style
      end
    end--style
    if ch == " " then
      if wysiwyg then
        local prevCh = "\0"
        if column == 0 then   -- At start of line, must put a &nbsp; because regular space will be collapsed
          prevCh = " "
        end
        while i < selEnd and exportutil.CharAt(i) == " " do
          if prevCh ~= " " then
            fp:write(" ")
          else
            fp:write("&nbsp;")
          end
          prevCh = exportutil.CharAt(i)
          i = i + 1
          column = column + 1
        end
        i = i - 1 -- the last incrementation will be done by the for loop
      else
        fp:write(" ")
        column = column + 1
      end
    elseif ch == "\t" then
        local ts = tabSize - column % tabSize
        if wysiwyg then
          for itab = 0, ts - 1 do
            if itab % 2 == 1 then
              fp:write(" ")
            else
              fp:write("&nbsp;")
            end
          end
          column = column + ts
        else
          if tabs then
            fp:write(ch)
            column = column + 1
          else
            fp:write(string.rep(" ", ts))
            column = column + ts
          end
        end--wysiwyg
    elseif ch == "\r" or ch == "\n" then
      if inStyleSpan then
        fp:write("</span>")
        inStyleSpan = false
      end
      if ch == "\r" and exportutil.CharAt(i + 1) == "\n" then
        i = i + 1 -- CR+LF line ending, skip the "extra" EOL char
      end
      column = 0
      if wysiwyg then
        fp:write("<br />")
      end

      styleCurrent = exportutil.StyleAt(i + 1)
      if folding then
          line = editor:LineFromPosition(i + 1)

          local lvl = editor.FoldLevel[line]
          newLevel = foldlevel(lvl)

          if newLevel < level then
            fp:write("</span>")
          end
          fp:write("\n")    -- here to get clean code
          if newLevel > level then
            fp:write("<span id=\"ln", line, "\">")
          end
          if foldheaderflag(lvl) then
            fp:write("<span onclick=\"toggle('ln", line + 1, "')\">-</span> ")
          else
            fp:write("&nbsp; ")
          end
          level = newLevel
      else
        fp:write("\n")
      end--folding

      if styleIsUsed[styleCurrent] and exportutil.CharAt(i + 1) ~= "\r"
         and exportutil.CharAt(i + 1) ~= "\n" then
        -- We know it's the correct next style,
        -- but no (empty) span for an empty line
        fp:write("<span class=\"S", styleCurrent, "\">")
        inStyleSpan = true
      end
    else
      if ch == "<" then
        fp:write("&lt;")
      elseif ch == ">" then
        fp:write("&gt;")
      elseif ch == "&" then
        fp:write("&amp;")
      else
        fp:write(ch)
      end
      column = column + 1
    end--if ch
    i = i + 1
  end--while

  if inStyleSpan then
    fp:write("</span>")
  end

  if folding then
    while level > 0 do
      fp:write("</span>")
      level = level - 1
    end
  end

  if not wysiwyg then
    fp:write("</pre>")
  else
    fp:write("</span>")
  end

  fp:write("\n</body>\n</html>\n")
  fp:close()
  if exportutil.VERBOSE ~= 0 then
    exportutil.progress("... done.")
  end
end

-- end of script
