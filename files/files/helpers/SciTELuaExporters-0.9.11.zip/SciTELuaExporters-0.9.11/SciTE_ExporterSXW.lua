-----------------------------------------------------------------------
-- SXW exporter in Lua for SciTE
-- Version 0.9.6, 20070805
--
-- Copyright 2004-2007 by Kein-Hong Man <khman@users.sf.net>
-- All Rights Reserved
--
-- Permission to use, copy, modify, and distribute this software and
-- its documentation for any purpose and without fee is hereby granted,
-- provided that the above copyright notice appear in all copies and
-- that both that copyright notice and this permission notice appear
-- in supporting documentation.
--
-- KEIN-HONG MAN DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
-- INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN
-- NO EVENT SHALL KEIN-HONG MAN BE LIABLE FOR ANY SPECIAL, INDIRECT OR
-- CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
-- OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
-- NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
-- WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
--
-----------------------------------------------------------------------
-- USAGE
--
-- * Remember to update sxw_preset.GENERATOR when version number changes
-- * Control characters are shown as numbers in << >> delimiters.
-- * If non-automatic named styles is selected, you can find the SciTE
--   styles and modify them using the OpenOffice.org Stylist (F11).
-- * Uses Reuben Thomas' bitwise function library if available, otherwise
--   it falls back to a slow 4-bit per round lookup xor function. The
--   library is currently in Bruce Dodson's recent builds (20040921).
--
-- * If your file uses UTF-8, then they are passed verbatim to OpenOffice,
--   which should be able to display them without any trouble (make sure
--   you have set Encoding to UTF-8 first, though.)
-- * UCS-2 currently not handled, while 8-bit values >127 are simply
--   converted to UTF-8 without any specific charset conversion. You might
--   need to use a charset converter to do things correctly.
-- * If the SXW refuses to open, it may be because the encoding of your
--   source document is not UTF-8 compliant.
--
-- * TODO when opening, sometimes the window area is not refreshed, this
--   happens on OOo 1.1.2 on Win32 -- not sure if this is a problem
-- * TODO eolfilled style property does not work (yet)
-- * TODO reverse video control characters (but not sure how to
--   slightly separate consecutive runs of control characters)
-----------------------------------------------------------------------
-- OPTIONS
--
-- * Paste them into your SciTEUser.properties file or equivalent in
--   order to make adjustments to the output. The property values given
--   are the script defaults.
-- * In the "configurable stuff" section in this script (line > 120):
--   (1) Table sxw.font_substitute allows you to substitute fonts
--   (2) Table sxw.paper_substitute is a table of paper sizes
--
-- * These are 0/1-style false/true properties:
--[[
# if 1, explicitly specify whites (for opaque whites)
export.sxw.whitewhites=0
# if 1, convert tabs to spaces (width in "tabsize" property)
export.sxw.converttabs=1
# if 1, use document's own tab width to format output
export.sxw.doctabs=1
# if 1, output used styles only
export.sxw.styleused=1
# if 1, enable background colouring
export.sxw.background=1
# if 0, disables font size, bold, italics, underline styles
# to disable fonts, use export.sxw.monofont
export.sxw.wysiwyg=1
# if 1, enable colours in exported documents
export.sxw.colour=1
# if 0, make styles available in Stylist for modifying
export.sxw.autostyle=0
# if 0, don't apply a text style to whitespace-only segments
export.sxw.spacestyled=0
--]]
--
-- * These are properties that require values:
--[[
# magnification (added to screen font size)
export.sxw.magnification=0
# if a font is specified, this overrides all other fonts, can be
# used as a monospace font mode enabler
export.sxw.monofont=Courier New
# size of tab stops, should have a unit suffix
export.sxw.tabstop=0.5inch
# portrait or landscape page orientation
export.sxw.orientation=portrait
# type of paper or a "width, height" pair with proper units
export.sxw.pagesize=a4
# margins: "top, bottom, left, right", with proper units
export.sxw.margins=1inch,1inch,1inch,1inch
--]]
--
------------------------------------------------------------------------
-- STRUCTURE
--
-- * Section 1 is configurable stuff
-- * Section 2 is for zero-compression deflate/zip
-- * Section 3 is for SXW output snippets
-- * Section 4 is the exporter proper
------------------------------------------------------------------------

-- if set, writes out a single XML file consisting of concatenated texts
-- instead of a zero-compression zip file; easier to open and peek into
--[[
local DEBUG = true --]]

local math = math
local string = string
local table = table

-----------------------------------------------------------------------
-- a simple check to alert of namespace collision, but allows different
-- files to define their own functions in the exporters table
-----------------------------------------------------------------------
if exporters then
  if exporters.SaveToSXW then
    error("SciTE_ExporterSXW: exporters.SaveToSXW already defined")
  end
  -- set pass-through if charset translation not initialized
  if not exportutil.CharsetFromSet then
    exportutil.CharsetFromSet = function(c) return c end
  end
else
  exporters = {}        -- create table
end

-----------------------------------------------------------------------
-- configurable stuff
-----------------------------------------------------------------------
local sxw = {}
local sxw_preset = {}

-- this is the identity of the creator
sxw_preset.GENERATOR = "SciTE Lua SXW Exporter 0.9.5"
-- page settings defaults (please override using SciTE properties)
sxw_preset.TABSIZE = 4
sxw_preset.TABSTOP = "0.5inch"
sxw_preset.PAPER = "a4" -- case sensitive
sxw_preset.ORIENTATION = "portrait"
sxw_preset.MARGIN = "1inch,1inch,1inch,1inch"

-----------------------------------------------------------------------
-- font substitution table
-----------------------------------------------------------------------
sxw.font_substitute = {
  --["Verdana"] = "Arial", -- example: switch all Verdana to Arial
  --[""] = "",
}

-----------------------------------------------------------------------
-- paper name substitution table
-- * some stuff on pages can be found in the following files:
--      svx/inc/paperinf.hxx
--      svx/source/dialog/{page.h|page.src|paperinf.cxx}
-----------------------------------------------------------------------
sxw.paper_substitute = {
  -- these were extracted from OpenOffice.org writer sample documents
  -- envelope sizes will probably not be very useful...
  ["a3"] = "11.6925inch,16.5354inch",
  ["a4"] = "8.2673inch,11.6925inch",
  ["a5"] = "5.8264inch,8.2673inch",
  ["letter"] = "8.5inch,11inch",
  ["legal"] = "8.5inch,14.002inch",
  ["tabloid"] = "11.0071inch,16.9791inch",
  ["b4 (iso)"] = "9.8425inch,13.8972inch",
  ["b5 (iso)"] = "6.9283inch,9.8425inch",
  ["b6 (iso)"] = "4.9209inch,6.9283inch",
  ["b4 (jis)"] = "10.1181inch,14.3307inch",
  ["b5 (jis)"] = "7.1654inch,10.1181inch",
  ["b6 (jis)"] = "5.039inch,7.1654inch",
  ["c4"] = "9.0161inch,12.7555inch",
  ["c5"] = "6.378inch,9.0161inch",
  ["c6"] = "4.4882inch,6.378inch",
  ["c65"] = "4.4882inch,8.9374inch",
  --[""] = "",
}

------------------------------------------------------------------------
-- Declarations for pieces of an SXW document, strings and functions
-- * these were extracted from OpenOffice 1.1.2 Win32 sample documents
-- * you can also refer to the OASIS Open Office Specification 1.0 as
--   well, PDF is at: http://www.oasis-open.org/committees/office/
------------------------------------------------------------------------

------------------------------------------------------------------------
-- must be the first entry for unix magic number mechanism, see specs
-- "mimetype" should be at file pos +30
-- actual mimetype should be at file pos +38
------------------------------------------------------------------------
sxw_preset.mimetype = 'application/vnd.sun.xml.writer'    -- mimetype

------------------------------------------------------------------------
-- settings.xml contents
--  (xml)
--  (settings_xml)
------------------------------------------------------------------------

sxw_preset.settings_xml = [[
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE office:document-settings PUBLIC "-//OpenOffice.org//DTD OfficeDocument 1.0//EN" "office.dtd">
<office:document-settings
 xmlns:office="http://openoffice.org/2000/office"
 xmlns:xlink="http://www.w3.org/1999/xlink"
 xmlns:config="http://openoffice.org/2001/config"
 office:version="1.0">
 <office:settings>
 </office:settings>
</office:document-settings>
]]

------------------------------------------------------------------------
-- Manifest file is currently hard-coded.
-- manifest.xml contents
--  (xml)
--  (manifest_xml) depends on (mimetype)
------------------------------------------------------------------------

sxw_preset.manifest_xml = [[
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE manifest:manifest PUBLIC "-//OpenOffice.org//DTD Manifest 1.0//EN" "Manifest.dtd">
<manifest:manifest xmlns:manifest="http://openoffice.org/2001/manifest">
 <manifest:file-entry manifest:media-type="]]..sxw_preset.mimetype..[[" manifest:full-path="/"/>
 <manifest:file-entry manifest:media-type="" manifest:full-path="Pictures/"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="content.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="styles.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="meta.xml"/>
 <manifest:file-entry manifest:media-type="text/xml" manifest:full-path="settings.xml"/>
</manifest:manifest>
]]

------------------------------------------------------------------------
-- meta.xml contents
--  (xml)
--  <office:meta> (MetaHeader)
--    sxw_make_meta(name, value)
--  </office:meta> (MetaFooter)
------------------------------------------------------------------------

sxw_preset.MetaHeader = [[
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE office:document-meta PUBLIC "-//OpenOffice.org//DTD OfficeDocument 1.0//EN" "office.dtd">
<office:document-meta
 xmlns:office="http://openoffice.org/2000/office"
 xmlns:xlink="http://www.w3.org/1999/xlink"
 xmlns:dc="http://purl.org/dc/elements/1.1/"
 xmlns:meta="http://openoffice.org/2000/meta"
 office:version="1.0">
 <office:meta>
]]
sxw_preset.MetaFooter = [[
 </office:meta>
</office:document-meta>
]]

-----------------------------------------------------------------------
-- styles.xml contents
--  (xml)
--  <office:document-styles> (StyleHeader)
--    <office:font-decls/>
--    <office:styles/>
--    <office:automatic-styles/>
--    <office:master-styles/>
--  </office:document-styles> (StyleFooter)
-----------------------------------------------------------------------

sxw_preset.StylesHeader = [[
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE office:document-styles PUBLIC "-//OpenOffice.org//DTD OfficeDocument 1.0//EN" "office.dtd">
<office:document-styles
 xmlns:office="http://openoffice.org/2000/office"
 xmlns:style="http://openoffice.org/2000/style"
 xmlns:text="http://openoffice.org/2000/text"
 xmlns:table="http://openoffice.org/2000/table"
 xmlns:draw="http://openoffice.org/2000/drawing"
 xmlns:fo="http://www.w3.org/1999/XSL/Format"
 xmlns:xlink="http://www.w3.org/1999/xlink"
 xmlns:number="http://openoffice.org/2000/datastyle"
 xmlns:svg="http://www.w3.org/2000/svg"
 xmlns:chart="http://openoffice.org/2000/chart"
 xmlns:dr3d="http://openoffice.org/2000/dr3d"
 xmlns:math="http://www.w3.org/1998/Math/MathML"
 xmlns:form="http://openoffice.org/2000/form"
 xmlns:script="http://openoffice.org/2000/script"
 office:version="1.0">
]]
sxw_preset.StylesFooter = [[
</office:document-styles>
]]
-- for reference only, unused, see StyleParagraphBeg, StyleParagraphEnd
sxw_preset.StyleDefaultParagraph = [[
<style:default-style
 style:family="paragraph">
 <style:properties
  style:use-window-font-color="true"
  style:font-name="Times New Roman"
  fo:font-size="12pt"
  fo:language="en"
  fo:country="US"
  style:font-name-asian="Arial Unicode MS"
  style:font-size-asian="12pt"
  style:language-asian="none"
  style:country-asian="none"
  style:font-name-complex="Tahoma"
  style:font-size-complex="12pt"
  style:language-complex="none"
  style:country-complex="none"
  fo:hyphenate="false"
  fo:hyphenation-remain-char-count="2"
  fo:hyphenation-push-char-count="2"
  fo:hyphenation-ladder-count="no-limit"
  style:text-autospace="ideograph-alpha"
  style:punctuation-wrap="hanging"
  style:line-break="strict"
  style:tab-stop-distance="0.4925inch"
  style:writing-mode="page"/>
</style:default-style>
]]
sxw_preset.StyleParagraphBeg = [[
<style:default-style
 style:family="paragraph">
 <style:properties
  style:use-window-font-color="true"
  fo:language="en"
  fo:country="US"
  style:font-name-asian="Arial Unicode MS"
  style:language-asian="none"
  style:country-asian="none"
  style:font-name-complex="Tahoma"
  style:language-complex="none"
  style:country-complex="none"
]]
sxw_preset.StyleParagraphEnd = [[
  fo:hyphenate="false"
  fo:hyphenation-remain-char-count="2"
  fo:hyphenation-push-char-count="2"
  fo:hyphenation-ladder-count="no-limit"
  style:text-autospace="ideograph-alpha"
  style:punctuation-wrap="hanging"
  style:line-break="strict"
  style:tab-stop-distance="%s"
  style:writing-mode="page"/>
</style:default-style>
]]
sxw_preset.StyleDefaultStandard = [[
<style:style
 style:name="Standard"
 style:family="paragraph"
 style:class="text"
/>
]]
-- note the %% for percentage sign
sxw_preset.PageMaster = [[
<style:page-master
 style:name="pm1">
 <style:properties
  fo:page-width="%s"
  fo:page-height="%s"
  style:num-format="1"
  style:print-orientation="%s"
  fo:margin-top="%s"
  fo:margin-bottom="%s"
  fo:margin-left="%s"
  fo:margin-right="%s"
  fo:background-color="transparent"
  style:writing-mode="lr-tb"
  style:footnote-max-height="0inch">
  <style:background-image/>
  <style:columns
   fo:column-count="0"
   fo:column-gap="0inch"/>
  <style:footnote-sep
   style:width="0.0071inch"
   style:distance-before-sep="0.0402inch"
   style:distance-after-sep="0.0402inch"
   style:adjustment="left"
   style:rel-width="25%%"
   style:color="#000000"/>
 </style:properties>
 <style:header-style/>
 <style:footer-style/>
</style:page-master>
]]
sxw_preset.MasterStyles = [[
<office:master-styles>
 <style:master-page style:name="Standard" style:page-master-name="pm1"/>
</office:master-styles>]]

-----------------------------------------------------------------------
-- content.xml contents
--  (xml)
--  <office:document-content> (ContentHeader)
--    <office:font-decls/>
--    <office:automatic-styles/>
--    <office:body>
--      <text:sequence-decls/> (ContentBodyPrelude)
--    </office:body>
--  </office:document-content> (ContentFooter)
-----------------------------------------------------------------------

sxw_preset.ContentHeader = [[
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE office:document-content PUBLIC "-//OpenOffice.org//DTD OfficeDocument 1.0//EN" "office.dtd">
<office:document-content
 xmlns:office="http://openoffice.org/2000/office"
 xmlns:style="http://openoffice.org/2000/style"
 xmlns:text="http://openoffice.org/2000/text"
 xmlns:table="http://openoffice.org/2000/table"
 xmlns:draw="http://openoffice.org/2000/drawing"
 xmlns:fo="http://www.w3.org/1999/XSL/Format"
 xmlns:xlink="http://www.w3.org/1999/xlink"
 xmlns:number="http://openoffice.org/2000/datastyle"
 xmlns:svg="http://www.w3.org/2000/svg"
 xmlns:chart="http://openoffice.org/2000/chart"
 xmlns:dr3d="http://openoffice.org/2000/dr3d"
 xmlns:math="http://www.w3.org/1998/Math/MathML"
 xmlns:form="http://openoffice.org/2000/form"
 xmlns:script="http://openoffice.org/2000/script"
 office:class="text" office:version="1.0">
<office:script/>
]]
-- optional; in <office:document-content><office:body>
sxw_preset.ContentBodyPrelude = [[
<text:sequence-decls>
 <text:sequence-decl text:display-outline-level="0" text:name="Illustration"/>
 <text:sequence-decl text:display-outline-level="0" text:name="Table"/>
 <text:sequence-decl text:display-outline-level="0" text:name="Text"/>
 <text:sequence-decl text:display-outline-level="0" text:name="Drawing"/>
</text:sequence-decls>
]]
sxw_preset.ContentFooter = [[
</office:document-content>
]]

------------------------------------------------------------------------
-- xml snippets
------------------------------------------------------------------------

sxw_preset.StyleHeader = [[
<style:style
 style:name="%s"
 style:family="text">
 <style:properties
]]
sxw_preset.StyleFooter = [[
 />
</style:style>
]]
sxw_preset.FontDecl = [[
<style:font-decl
 style:name="%s"
 fo:font-family="&apos;%s&apos;"
%s%s/>
]]
sxw_preset.FontName = [[
  style:font-name="%s"
]]
sxw_preset.FontSize = [[
  fo:font-size="%spt"
  style:font-size-asian="%spt"
  style:font-size-complex="%spt"
]]
sxw_preset.FontFore = [[
  fo:color="%s"
]]
sxw_preset.FontBack = [[
  style:text-background-color="%s"
]]
-- normal or bold
sxw_preset.FontBold = [[
  fo:font-weight="%s"
  style:font-weight-asian="%s"
  style:font-weight-complex="%s"
]]
-- normal or italic
sxw_preset.FontItalics = [[
  fo:font-style="%s"
  style:font-style-asian="%s"
  style:font-style-complex="%s"
]]
-- normal or single
sxw_preset.FontUnderline = [[
  style:text-underline="%s"
  style:text-underline-color="font-color"
]]

------------------------------------------------------------------------
-- font handling for <office:font-decls/>
-- style:font-family-generic and style:font-pitch does not seem to be
-- critical for operation, unless perhaps if the font is missing...
------------------------------------------------------------------------

function sxw.add_font(font, family, pitch)
  if sxw.fonts == nil then sxw.fonts = {} end
  local font_family = ""
  local font_pitch = ""
  -- substitute font if appropriate
  local subst = sxw.font_substitute[font]
  if subst then
    font = subst
  else
    -- handle family and pitch if specified
    if family then
      font_family = string.format([[ style:font-family-generic="%s"\n]], family)
    end
    if pitch then
      font_pitch = string.format([[ style:font-pitch="%s"\n]], pitch)
    end
  end
  local font_decl = string.format(sxw_preset.FontDecl,
                      font, font, font_family, font_pitch)
  for i,v in ipairs(sxw.fonts) do
    if v == font_decl then return font end
  end
  table.insert(sxw.fonts, font_decl)
  return font
end

function sxw.font_table()
  local snippet = ""
  for i,v in ipairs(sxw.fonts) do
    snippet = snippet..v
  end
  return "<office:font-decls>\n"..snippet..
         "</office:font-decls>\n"
end

-----------------------------------------------------------------------
-- UNUSED control character lookup (note array starts from index 1)
-- for future use, if reverse-video display-style format is needed
-----------------------------------------------------------------------

sxw.ascii_lookup = {
  "NUL", "SOH", "STX", "ETX", "EOT", "ENQ", "ACK", "BEL", -- ascii 0-7
  "BS",  "HT",  "LF",  "VT",  "FF",  "CR",  "SO",  "SI",  -- ascii 8-15
  "DLE", "DC1", "DC2", "DC3", "DC4", "NAK", "SYN", "ETB", -- ascii 16-23
  "CAN", "EM",  "SUB", "ESC", "FS",  "GS",  "RS",  "US",  -- ascii 24-31
}

------------------------------------------------------------------------
-- zero-compression zip writer from nullzip.lua ver 0.9.5, by KHMan
------------------------------------------------------------------------
-- Selected Notes:
-- * Note: these notes are for the 4-bit per round lookup xor...
-- * the output is limited to primitive header blocks (no zip64 records)
-- * CRC is disappointingly slow, is there any other way to do it?
-- * writes out data at about 100K/sec on an Athlon 2500+
--   (100 calls to nullzip_test() 4.5K sxw writing test in 10 sec)
-- * updated here to Lua 5.1 code 20070805; performance untested
------------------------------------------------------------------------

-- auto-select proper functions to use based on availability of the
-- bitwise function library; then checks function vars just to be sure
local bxor, band, bshr
if type(bit) == "table" then
  bxor = bit.bxor
  band = bit.band
  bshr = bit.rshift
end
if not bxor or not band or not bshr then
  bxor = nil
end

------------------------------------------------------------------------
-- Pack values into little-endian string bytes
------------------------------------------------------------------------

local function u16(n)
  local c0 = n % 256; n = (n - c0) / 256
  local c1 = n % 256
  return string.char(c0, c1)
end

local function u32(n)
  local c0 = n % 256; n = (n - c0) / 256
  local c1 = n % 256; n = (n - c1) / 256
  local c2 = n % 256; n = (n - c2) / 256
  local c3 = n % 256
  return string.char(c0, c1, c2, c3)
end

------------------------------------------------------------------------
-- Compute bitwise xor using a 4 bit-at-a-time table lookup. Is there
-- any faster xor-calculating algorithm on vanilla Lua? Or a CRC
-- algorithm that doesn't use (or use fewer) xor (or bitwise) ops?
-- * strings and handling lookups in byte chunks is not faster
-- * a 64K lookup table is 40% faster
-- * a 64K string byte-lookup is 50% faster
-- * building 64K tables is slow, but perhaps can load a binary file...
------------------------------------------------------------------------

local xor_lookup, xor_init, xor
if not bxor then
  xor_lookup = {}

  function xor_init()
    local idx = 0
    for x = 0, 15 do
      for y = 0, 15 do
        local bz = 1
        local xx = x; local yy = y
        xor_lookup[idx] = 0
        for z = 1, 4 do
          if xx % 2 ~= yy % 2 then
            xor_lookup[idx] = xor_lookup[idx] + bz
          end
          xx = math.floor(xx / 2); yy = math.floor(yy / 2)
          bz = bz * 2
        end
        idx = idx + 1
      end
    end
  end

  function xor(x, y, size)
    local z = 0
    local nz = 1
    size = size or 8
    for n = 1, size do
      local nx = x % 16; x = (x - nx) / 16
      local ny = y % 16; y = (y - ny) / 16
      z = xor_lookup[nx * 16 + ny] * nz + z
      nz = nz * 16
    end
    return z
  end

  xor_init()
end--if not bxor

------------------------------------------------------------------------
-- nulldeflate: wraps no-compression header bytes around data, split into
-- separate blocks if necessary
-- * OpenOffice 1.1.2 on Win32 doesn't accept method 0 (store) so
--   deflating seems to be a must
------------------------------------------------------------------------

local nulldeflate
if bxor then
  nulldeflate =
function(ibuf)
  local obuf = {}
  while #ibuf > 0 do
    local seg
    local block
    local ilen = #ibuf
    if ilen > 65535 then        -- cleave a block
      block = string.sub(ibuf, 1, 65535)
      ibuf = string.sub(ibuf, 65536)
    else                        -- whole block
      block = ibuf
      ibuf = ""
    end
    if #ibuf > 0 then
      seg = "\0"                -- header bits 000, padded
    else                        -- to nearest byte boundary
      seg = "\1"                -- 001, last block
    end
    local olen = #block
    seg = seg..u16(olen)        -- LEN
    olen = bxor(olen, 65535)    -- 16-bit xor
    seg = seg..u16(olen)        -- NLEN
    table.insert(obuf, seg)
    table.insert(obuf, block)   -- uncompressed data
  end
  return table.concat(obuf)
end
else-- if not bxor
  nulldeflate =
function(ibuf)
  local obuf = ""
  while #ibuf > 0 do
    local block
    local ilen = #ibuf
    if ilen > 65535 then        -- cleave a block
      block = string.sub(ibuf, 1, 65535)
      ibuf = string.sub(ibuf, 65536)
    else                        -- whole block
      block = ibuf
      ibuf = ""
    end
    if #ibuf > 0 then
      obuf = obuf.."\0"         -- header bits 000, padded
    else                        -- to nearest byte boundary
      obuf = obuf.."\1"         -- 001, last block
    end
    local olen = #block
    obuf = obuf..u16(olen)      -- LEN
    olen = xor(olen, 65535, 4)  -- 16-bit xor
    obuf = obuf..u16(olen)      -- NLEN
    obuf = obuf..block          -- uncompressed data
  end
  return obuf
end
end--if bxor

------------------------------------------------------------------------
-- Straight adaptation of CRC32 code from RFC 1952 (from ISO 3309/ITU-T
-- V.42). The crc should be initialized to zero. Pre- and post-
-- conditioning (one's complement) is performed within
-- nullzip_update_crc so it shouldn't be done by the caller.
------------------------------------------------------------------------

local nullzip_crc_table         -- table of CRCs of all 8-bit messages

------------------------------------------------------------------------
-- nullzip_make_crc_table: make the table for a fast CRC.
-- Can be replaced by the precomputed table instead.
-- Usage: crc = nullzip_crc(data)
------------------------------------------------------------------------

local nullzip_make_crc_table
if bxor then
  nullzip_make_crc_table =
function()
  local CONST1 = 0xEDB88320
  nullzip_crc_table = {}
  for n = 0, 255 do
    local c = n
    for k = 0, 7 do
      if bit.mod(c, 2) == 1 then
        -- c = 0xedb88320L ^ (c >> 1);
        c = bxor(CONST1, bshr(c, 1))
      else
        c = bshr(c, 1)
      end
    end
    nullzip_crc_table[n] = c
  end
end
else--if not bxor
  nullzip_make_crc_table =
function()
  local CONST1 = 0xEDB88320
  nullzip_crc_table = {}
  for n = 0, 255 do
    local c = n
    for k = 0, 7 do
      if c % 2 == 1 then
        -- c = 0xedb88320L ^ (c >> 1);
        c = xor(CONST1, math.floor(c / 2))
      else
        c = math.floor(c / 2)
      end
    end
    nullzip_crc_table[n] = c
  end
end
end--if bxor

------------------------------------------------------------------------
-- nullzip_update_crc: update a running crc with a specified buffer
-- Usage: crc = nullzip_crc(original_crc, data)
------------------------------------------------------------------------

local nullzip_update_crc
if bxor then
  nullzip_update_crc =
function(original_crc, data)
  local CONST1 = 0xFFFFFFFF
  local c = bxor(original_crc, CONST1)
  if not nullzip_crc_table then
    nullzip_make_crc_table()
  end
  for n = 1, #data do
    -- c = crc_table[(c ^ buf[n]) & 0xff] ^ (c >> 8);
    c = bxor(nullzip_crc_table[band(bxor(c, string.byte(data, n)), 255)],
            bshr(c, 8))
  end
  return bxor(c, CONST1)
end
else--if not bxor
  nullzip_update_crc =
function(original_crc, data)
  local CONST1 = 0xFFFFFFFF
  local c = xor(original_crc, CONST1)
  if not nullzip_crc_table then
    nullzip_make_crc_table()
  end
  for n = 1, #data do
    -- c = crc_table[(c ^ buf[n]) & 0xff] ^ (c >> 8);
    c = xor(nullzip_crc_table[xor(c, string.byte(data, n), 2)],
            math.floor(c / 256))
  end
  return xor(c, CONST1)
end
end--if bxor

------------------------------------------------------------------------
-- nullzip_crc: return the crc of a specified buffer, as a binary string
-- Usage: crc = nullzip_crc(data)
------------------------------------------------------------------------

local function nullzip_crc(data)
  return u32(nullzip_update_crc(0, data))
end

------------------------------------------------------------------------
-- Returns MS-DOS formatted date and time in 4 bytes.
-- Usage: time = nullzip_time()
------------------------------------------------------------------------

local function nullzip_time()
  dt = os.date("*t")
  dt.year = (dt. year - 1980) % 128

  local dostime = dt.hour * 2048            -- 15-11 hour 0-23
                + dt.min * 32               -- 10-5  minutes 0-59
                + math.floor(dt.sec / 2)    -- 4-0   secs in 2s units
  local dosdate = dt.year * 512             -- 15-9  year 0-119 (f. 1980)
                + dt.month * 32             -- 8-5   month 1-12
                + dt.day                    -- 4-0   days 1-31
  return u16(dostime)..u16(dosdate)
end

------------------------------------------------------------------------
-- Current zip file data.
------------------------------------------------------------------------

local nullzip_data              -- local headers and file data
local nullzip_cdr               -- central directory record
local nullzip_entries           -- entries in central directory
local nullzip_offset            -- output file pointer

------------------------------------------------------------------------
-- Clears the central directory record data prior to writing files.
-- Usage: nullzip_init();
------------------------------------------------------------------------

function nullzip_init()
  nullzip_data = {}
  nullzip_cdr = {}
  nullzip_entries = 0
  nullzip_offset = 0
end

------------------------------------------------------------------------
-- Adds a directory. Directory should have a trailing forward slash.
-- Usage: nullzip_add_dir(dirname)
------------------------------------------------------------------------

function nullzip_add_dir(dirname)
  local dirlength = #dirname
  local mtime = nullzip_time()

  ----------------------------------------------------------------
  -- local file header
  ----------------------------------------------------------------
  local ziplfh =
    u32(0x04034b50)..   -- DD signature
    u16(20)..           -- DW version needed to extract
    u16(0)..            -- DW general purpose bit flag
    u16(0)..            -- DW compression method (0=none,8=deflate)
    mtime..             -- DD last mod time & date
    u32(0)..            -- DD crc-32
    u32(0)..            -- DD compressed size
    u32(0)..            -- DD uncompressed size
    u16(dirlength)..    -- DW file name length
    u16(0)..            -- DW extra field length
    dirname             -- DB name of directory


  if DEBUG then
    local debug_data =
      "<!-- directory entry=\""..dirname.."\" -->\n"
    table.insert(nullzip_data, debug_data)
  else
    table.insert(nullzip_data, ziplfh)
  end

  ----------------------------------------------------------------
  -- central directory file header
  ----------------------------------------------------------------
  local zipcfh =
    u32(0x02014b50)..   -- DD signature
    u16(20)..           -- DW version made by
    u16(20)..           -- DW version needed to extract
    u16(0)..            -- DW general purpose bit flag
    u16(0)..            -- DW compression method
    mtime..             -- DD last mod time & date
    u32(0)..            -- DD crc-32
    u32(0)..            -- DD compressed size
    u32(0)..            -- DD uncompressed size
    u16(dirlength)..    -- DW file name length
    u16(0)..            -- DW extra field length
    u16(0)..            -- DW file comment length
    u16(0)..            -- DW disk number start
    u16(0)..            -- DW internal file attributes
    u32(16)..           -- DD external file attributes
    u32(nullzip_offset)..       -- DD relative offset of local header
    dirname             -- DB name of directory

  table.insert(nullzip_cdr, zipcfh)
  nullzip_entries = nullzip_entries + 1
  nullzip_offset = nullzip_offset + #ziplfh
end

------------------------------------------------------------------------
-- Adds a file, given the filename (plus relative path if it exists), and
-- the file data.
-- Usage: nullzip_add_file(filename, filedata)
------------------------------------------------------------------------

function nullzip_add_file(filename, filedata)
  local compdata = nulldeflate(filedata)
  local namelength = #filename
  local mtime = nullzip_time()
  local crc = ""
  if not DEBUG then crc = nullzip_crc(filedata) end
  local csize = u32(#compdata)
  local usize = u32(#filedata)

  ----------------------------------------------------------------
  -- local file header
  ----------------------------------------------------------------
  local ziplfh =
    u32(0x04034b50)..   -- DD signature
    u16(20)..           -- DW version needed to extract
    u16(0)..            -- DW general purpose bit flag
    u16(8)..            -- DW compression method
    mtime..             -- DD last mod time & date
    crc..               -- DD crc-32
    csize..             -- DD compressed size
    usize..             -- DD uncompressed size
    u16(namelength)..   -- DW file name length
    u16(0)..            -- DW extra field length
    filename            -- DB name of file

  if DEBUG then
    local debug_data
      = "<!-- file entry=\""..filename.."\" -->\n"..filedata
    table.insert(nullzip_data, debug_data)
  else
    table.insert(nullzip_data, ziplfh)
    table.insert(nullzip_data, compdata)
  end

  ----------------------------------------------------------------
  -- central directory file header
  ----------------------------------------------------------------
  local zipcfh =
    u32(0x02014b50)..           -- DD signature
    u16(20)..                   -- DW version made by
    u16(20)..                   -- DW version needed to extract
    u16(0)..                    -- DW general purpose bit flag
    u16(8)..                    -- DW compression method
    mtime..                     -- DD last mod time & date
    crc..                       -- DD crc-32
    csize..                     -- DD compressed size
    usize..                     -- DD uncompressed size
    u16(namelength)..           -- DW file name length
    u16(0)..                    -- DW extra field length
    u16(0)..                    -- DW file comment length
    u16(0)..                    -- DW disk number start
    u16(0)..                    -- DW internal file attributes
    u32(32)..                   -- DD external file attributes
    u32(nullzip_offset)..       -- DD relative offset of local header
    filename                    -- DB name of file

  table.insert(nullzip_cdr, zipcfh)
  nullzip_entries = nullzip_entries + 1
  nullzip_offset = nullzip_offset + #ziplfh + #compdata
end

------------------------------------------------------------------------
-- Returns the whole data set ready to be written to disk.
-- Usage: filedata = nullzip_filedata()
------------------------------------------------------------------------

function nullzip_filedata()
  ----------------------------------------------------------------
  -- central directory record
  ----------------------------------------------------------------
  local cdr = table.concat(nullzip_cdr)
  local centraldir =
    u32(0x06054b50)..           -- DD central dir signature
    u16(0)..                    -- DW number of this disk
    u16(0)..                    -- DW disk with cen dir start
    u16(nullzip_entries)..      -- DW entries in cen dir
    u16(nullzip_entries)..      -- DW total entries
    u32(#cdr)..                 -- DD size of central directory
    u32(nullzip_offset)..       -- DD offset of cen dir start
    u16(0)                      -- DW .ZIP file comment length

  -- perform minimal concatenations
  if DEBUG then
    return table.concat(nullzip_data)
  end
  cdr = cdr..centraldir
  table.insert(nullzip_data, cdr)
  return table.concat(nullzip_data)
end

-- * nullzip.lua test functions removed *

-----------------------------------------------------------------------
-- exporters:SaveToSXW
--
-- Exports the document in the current window to an SXW format file.
--
-----------------------------------------------------------------------
function exporters:SaveToSXW()
  ---------------------------------------------------------------------
  -- XML standard entities (always present; part of XML standard)
  ---------------------------------------------------------------------
  local entities = {
    ["&"] = "&amp;", ["<"] = "&lt;", [">"] = "&gt;",
    ["'"] = "&apos;", ["\""] = "&quot;",
  }

  ---------------------------------------------------------------------
  -- text selection
  ---------------------------------------------------------------------
  local selBeg, selEnd = exportutil.GetSelPos()
  editor:Colourise(0, -1)

  ---------------------------------------------------------------------
  -- UTF-8 encoding flag (UCS-2 currently not handled), boolean
  ---------------------------------------------------------------------
  local utf8 = editor.CodePage == SC_CP_UTF8
  -- was scite.SendEditor(SCI_GETCODEPAGE) (only in SciTE post-1.61)

  ---------------------------------------------------------------------
  -- tab to space value
  ---------------------------------------------------------------------
  local tabSize = tonumber(props["tabsize"])
  if not tabSize or tabSize <= 0 or tabSize >= 99 then
    tabSize = sxw_preset.TABSIZE
  end
  if exportutil.propbool("export.sxw.doctabs", 1) then
    tabSize = editor.TabWidth
  end

  ---------------------------------------------------------------------
  -- boolean flags
  ---------------------------------------------------------------------
  -- TODO opaque whites may depend on a global SXW property; to check
  local whiteWhites = exportutil.propbool("export.sxw.whitewhites")
  local convertTabs = exportutil.propbool("export.sxw.converttabs", 1)
  local stylesUsed = exportutil.propbool("export.sxw.styleused", 1)
  local background = exportutil.propbool("export.sxw.background", 1)
  local wysiwyg = exportutil.propbool("export.sxw.wysiwyg", 1)
  local colour = exportutil.propbool("export.sxw.colour", 1)
  local autoStyle = exportutil.propbool("export.sxw.autostyle")
  local spaceStyled = exportutil.propbool("export.sxw.spacestyled")

  ---------------------------------------------------------------------
  -- valued properties
  ---------------------------------------------------------------------
  -- returns comma-separated fields in a property value as a list
  local function parseProp(propValue)
    local propList = {}
    if not propValue or propValue == "" then
      return propList
    end
    for v in string.gfind(propValue, "([^,]+),?") do
      table.insert(propList, v)
    end
    return propList
  end

  -- magnification value to add to screen font size
  local magnification = tonumber(props["export.sxw.magnification"]) or 0
  -- font override property
  local monoFont = props["export.sxw.monofont"]
  if not monoFont or monoFont == "" then
    monoFont = nil
  end
  -- tab stop setting
  local tabStop = props["export.sxw.tabstop"]
  if not tabStop or tabStop == "" then
    tabStop = sxw_preset.TABSTOP
  end
  -- page orientation
  local orientation = props["export.sxw.orientation"]
  if not orientation or orientation == "" then
    orientation = sxw_preset.ORIENTATION
  end
  -- paper size: paper name or width, height
  local paper = string.lower(props["export.sxw.pagesize"])
  local pageSize = sxw.paper_substitute[paper] or paper
  if not pageSize or pageSize == "" then
    pageSize = parseProp(sxw.paper_substitute[sxw_preset.PAPER])
    if string.lower(orientation) == "landscape" then
      pageSize[1], pageSize[2] = pageSize[2], pageSize[1]
    end
  else
    pageSize = parseProp(pageSize)
  end
  -- page margins: top, bottom, left, right
  pageMargins = parseProp(props["export.sxw.margins"])
  if #pageMargins ~= 4 then
    pageMargins = parseProp(sxw_preset.MARGIN)
  end

  ---------------------------------------------------------------------
  -- dump all styles or only styles that are used
  ---------------------------------------------------------------------
  local styleIsUsed = {}
  if stylesUsed then
    for i = selBeg, selEnd - 1 do
      styleIsUsed[exportutil.StyleAt(i)] = true
    end
  else
    for i = 0, exportutil.STYLE_MAX do
      styleIsUsed[i] = true
    end
  end
  styleIsUsed[exportutil.STYLE_DEFAULT] = true

  ---------------------------------------------------------------------
  -- style handling
  ---------------------------------------------------------------------
  stylemgr:setlexer(editor.Lexer)
  -- helper functions
  local function IsSpecified(sd, field)
    return (string.find(sd.specified, field, 1, 1))
  end
  local function IsOpaqueColour(c)
    if not whiteWhites and c == "#FFFFFF" then return false end
    return true
  end

  -- create style names, make them more verbose if non-automatic styles
  -- selected (that is, named styles that can be listed and modified)
  local stylePrefix
  local style = {}; local rstyle = {}
  local styleName = {}
  if autoStyle then
    stylePrefix = "S"
  else
    stylePrefix = (stylemgr:getlexerlanguage() or "txt").."_S"
  end

  -- build style specifications
  for i = 0, exportutil.STYLE_MAX do
    if styleIsUsed[i] then
      -- read and process style entry
      local sd = stylemgr:locate(i)
      styleName[i] = [[<text:span text:style-name="]]..stylePrefix..i..[[">]]
      -- start of style specification
      local st = string.format(sxw_preset.StyleHeader, stylePrefix..i)

      if sd.specified ~= "" then
        -- handle font naming and monofont override
        if IsSpecified(sd, "font") then
          if not monoFont then
            local actual_font = sxw.add_font(sd.font)
            st = st..string.format(sxw_preset.FontName, actual_font)
          elseif monoFont and i == exportutil.STYLE_DEFAULT then
            local actual_font = sxw.add_font(monoFont)
            st = st..string.format(sxw_preset.FontName, actual_font)
          end
        end
        -- handle font properties optionally
        if wysiwyg or i == exportutil.STYLE_DEFAULT then
          if IsSpecified(sd, "size") then
            sd.size = sd.size + magnification
            st = st..string.format(sxw_preset.FontSize, sd.size, sd.size, sd.size)
          end
        end
        if wysiwyg then
          if IsSpecified(sd, "italics") then
            local v = sd.italics and "italic" or "normal"
            st = st..string.format(sxw_preset.FontItalics, v, v, v)
          end
          if IsSpecified(sd, "bold") then
            local v = sd.bold and "bold" or "normal"
            st = st..string.format(sxw_preset.FontBold, v, v, v)
          end
          if IsSpecified(sd, "underlined") then
            local v = sd.underlined and "single" or "none"
            st = st..string.format(sxw_preset.FontUnderline, v)
          end
        end--if wysiwyg
        --if IsSpecified(sd, "eolfilled") and sd.eolfilled then
          -- TODO low priority; is this even possible?
        --end
        -- handle foreground and background optionally
        if colour then
          local c = stylemgr:hexstr(sd.fore)
          if IsSpecified(sd, "fore") and IsOpaqueColour(c) then
            st = st..string.format(sxw_preset.FontFore, c)
          end
          c = stylemgr:hexstr(sd.back)
          if background and IsSpecified(sd, "back") and IsOpaqueColour(c) then
            st = st..string.format(sxw_preset.FontBack, c)
          end
        end--if colour
      end
      -- end of style specification
      style[i] = st..sxw_preset.StyleFooter
    end--if styleIsUsed
  end--for i

  ---------------------------------------------------------------------
  -- patch in default styles from processed version of style number 32
  -- because all styles will inherit them from "Standard"
  ---------------------------------------------------------------------
  local _, _, prop_add
    = string.find(style[exportutil.STYLE_DEFAULT],
                  "%s<style:properties\n(.+)%s/>\n")
  sxw_preset.StyleParagraph =
    sxw_preset.StyleParagraphBeg..prop_add..
    string.format(sxw_preset.StyleParagraphEnd, tabStop)

  ---------------------------------------------------------------------
  -- main loop
  ---------------------------------------------------------------------
  local data = {}; local line = {}
  local seg = ""; local notwhitespace = false
  local column = 0; local spaces = 0
  local i = selBeg
  local styleCurrent

  ---------------------------------------------------------------------
  -- write out representation of space characters
  ---------------------------------------------------------------------
  function flushSpaces()
    if spaces == 1 then
      -- at the start of a paragraph, whitespace zapped, I think
      if line[2] then
        seg = seg.." "
      else
        seg = seg..[[<text:s/>]]
      end
    --elseif spaces == 2 then    -- doesn't work, must have text:c prop
    --  seg = seg.." <text:s/>"  -- used only *within* a style
    else-- spaces > 2 then
      seg = seg..string.format([[<text:s text:c="%s"/>]], spaces)
    end
    spaces = 0
  end
  ---------------------------------------------------------------------
  -- apply style to a line segment
  ---------------------------------------------------------------------
  function styleSegment(segment)
    if notwhitespace or spaceStyled then
      -- table.concat is slightly slower
      --return table.concat{styleName[styleCurrent], segment, [[</text:span>]]}
      return styleName[styleCurrent]..segment..[[</text:span>]]
    end
    return segment
  end

  while i < selEnd do
    local ch = exportutil.CharAt(i)
    local styleNow = exportutil.StyleAt(i)
    -------------------------------------------------------------------
    -- handle newlines
    -------------------------------------------------------------------
    if ch == "\n" or ch == "\r" then
      if ch == "\r" and exportutil.CharAt(i + 1) == "\n" then i = i + 1 end
      if column == 0 then
        -- empty line optimization
        table.insert(data, "<text:p text:style-name=\"Standard\"/>\n")
      else
        table.insert(line, styleSegment(seg))
        table.insert(line, "</text:p>\n")
        table.insert(data, table.concat(line))
      end
      column = 0
      line = {}; styleCurrent = nil
      seg = ""; notwhitespace = false
    -------------------------------------------------------------------
    -- handle style change (always true at beginning of line)
    -------------------------------------------------------------------
    elseif styleNow ~= styleCurrent then
      -- close previous text span if required
      if column > 0 then
        if spaces > 0 then flushSpaces() end
        table.insert(line, styleSegment(seg))
      else
        -- start of line here
        line = {[[<text:p text:style-name="Standard">]]}
      end
      seg = ""; notwhitespace = false
      styleCurrent = styleNow
    end--style
    -------------------------------------------------------------------
    -- output runs of space characters
    -------------------------------------------------------------------
    if spaces > 0 then
      if ch == " " or (ch == "\t" and convertTabs) then
        -- more spaces to come, keep counting
      else
        flushSpaces()
      end
    end
    -------------------------------------------------------------------
    -- handle spaces (actually handled above)
    -------------------------------------------------------------------
    if ch == " " then
      spaces = spaces + 1
      column = column + 1
    -------------------------------------------------------------------
    -- handle tabs
    -------------------------------------------------------------------
    elseif ch == "\t" then
      if convertTabs then
        local ts = tabSize - column % tabSize
        spaces = spaces + ts
        column = column + ts
      else
        seg = seg.."<text:tab-stop/>"
        column = column + 1
      end
    -------------------------------------------------------------------
    -- handle control characters
    -------------------------------------------------------------------
    else
      local c = string.byte(ch)
      notwhitespace = true
      if c < 32 then
        if ch ~= "\r" and ch ~= "\n" then
          -- ALTERNATIVES control char handling seems to use style 36
          -- use sxw.ascii_lookup[string.byte(ch) + 1] to get ASCII names
          -- with the method below, we can still see the value...
          local ctrl = "«"..c.."»"
          seg = seg..ctrl
          column = column + #ctrl
        end
      -----------------------------------------------------------------
      -- handle characters with codes > 127 (conversion to UTF-8 with
      -- optional charset conversion)
      -----------------------------------------------------------------
      elseif c > 127 then
        if not utf8 then
          c = exportutil.CharsetToUTF8(c)
          if c >= 2048 then
            ch = string.char(224 + math.floor(c / 4096),
                             128 + math.floor(c / 64) % 64,
                             128 + c % 64)
          elseif c >= 128 then
            ch = string.char(192 + math.floor(c / 64),
                             128 + c % 64)
          else
            ch = string.char(c)
          end
        end
        seg = seg..ch
        column = column + 1
      -----------------------------------------------------------------
      -- handle normal characters
      -----------------------------------------------------------------
      else
        seg = seg..(entities[ch] or ch)
        column = column + 1
      end
    end--if ch
    i = i + 1
  end--while

  -- clean up if last line has no EOL
  if seg ~= "" or #line > 0 then
    if spaces > 0 then flushSpaces() end
    table.insert(line, styleSegment(seg).."</text:p>\n")
    table.insert(data, table.concat(line))
  else
    table.insert(data, "<text:p text:style-name=\"Standard\"/>\n")
  end

  ---------------------------------------------------------------------
  -- open exported file for saving
  ---------------------------------------------------------------------
  local fileExt = "sxw"; if DEBUG then fileExt = "xml" end

  local saveName = exportutil.exportfile(props["FileDir"], props["FileName"], fileExt)
  local fp = io.open(saveName, "wb")
  if not fp then
    error("exporters:SaveToSXW: could not save file \""..saveName.."\"")
  end
  if exportutil.VERBOSE ~= 0 then
    _ALERT("\nExporting to SXW, filepath: "..saveName)
  end

  ---------------------------------------------------------------------
  -- build the files
  ---------------------------------------------------------------------

  -- simple stripped-down files first, then more complex ones
  nullzip_init()
  -- mimetype (first file, for unix magic number handling)
  nullzip_add_file("mimetype", sxw_preset.mimetype)
  -- manifest directory
  nullzip_add_dir("META-INF/")
  -- manifest.xml
  nullzip_add_file("META-INF/manifest.xml", sxw_preset.manifest_xml)
  -- settings.xml
  nullzip_add_file("settings.xml", sxw_preset.settings_xml)

  ---------------------------------------------------------------------
  -- meta.xml
  ---------------------------------------------------------------------
  -- builds a document meta information entry
  local function sxw_make_meta(name, value)
    return "  <meta:"..name..">"..value.."</meta:"..name..">\n"
  end

  local meta_xml = {
    sxw_preset.MetaHeader,
    sxw_make_meta("generator", sxw_preset.GENERATOR),
    sxw_make_meta("initial-creator", sxw_preset.GENERATOR),
    -- ISO 8601 date
    sxw_make_meta("creation-date", os.date("%Y-%m-%dT%H:%M:%S")),
    sxw_preset.MetaFooter,
  }
  nullzip_add_file("meta.xml", table.concat(meta_xml))

  ---------------------------------------------------------------------
  -- writes out SciTE-specific style set
  ---------------------------------------------------------------------
  local function sxw_styles()
    local sData = ""
    for _,sItem in pairs(style) do
      sData = sData..sItem
    end
    return sData
  end

  ---------------------------------------------------------------------
  -- styles.xml (see earlier comments for structural outline)
  ---------------------------------------------------------------------
  local font_decl = sxw.font_table()    -- also in content.xml
  local font_styles = ""
  if not autoStyle then
    font_styles = sxw_styles()
  end
  local pageSettings =
    string.format(sxw_preset.PageMaster,
      pageSize[1], pageSize[2], orientation,
      pageMargins[1], pageMargins[2], pageMargins[3], pageMargins[4])
  local styles_xml = {
    sxw_preset.StylesHeader,
    font_decl,
    "<office:styles>\n",
    sxw_preset.StyleParagraph,
    sxw_preset.StyleDefaultStandard,
    font_styles,
    "</office:styles>\n",
    "<office:automatic-styles>\n",
    pageSettings,
    "</office:automatic-styles>\n",
    sxw_preset.MasterStyles,
    sxw_preset.StylesFooter,
  }
  nullzip_add_file("styles.xml", table.concat(styles_xml))

  ---------------------------------------------------------------------
  -- content.xml (see earlier comments for structural outline)
  ---------------------------------------------------------------------
  font_styles = ""
  if autoStyle then
    font_styles = sxw_styles()
  end
  local content_xml = {
    sxw_preset.ContentHeader,
    font_decl,
    "<office:automatic-styles>\n",
    font_styles,
    "</office:automatic-styles>\n",
    "<office:body>\n",
    table.concat(data),
    "</office:body>\n",
    sxw_preset.ContentFooter,
  }
  nullzip_add_file("content.xml", table.concat(content_xml))

  ---------------------------------------------------------------------
  -- write and close exported file
  ---------------------------------------------------------------------
  fp:write(nullzip_filedata())
  fp:close()
  if exportutil.VERBOSE ~= 0 then
    exportutil.progress("... done.")
  end
end

-- end of script
