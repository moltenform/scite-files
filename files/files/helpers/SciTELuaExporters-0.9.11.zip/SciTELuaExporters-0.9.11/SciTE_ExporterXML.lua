-----------------------------------------------------------------------
-- XML exporter in Lua for SciTE
-- Version 0.9.4, 20070805
--
-- Adapted from SciTE sources (scite/src/Exporters.cxx CVS 20040723)
-- by Kein-Hong Man <khman@users.sf.net> (This is a straightforward
-- conversion and so I decline to claim it as my own.)
--
-- Copyright 1998-2007 by Neil Hodgson <neilh@scintilla.org>
-- All Rights Reserved
--
-- Permission to use, copy, modify, and distribute this software and
-- its documentation for any purpose and without fee is hereby granted,
-- provided that the above copyright notice appear in all copies and
-- that both that copyright notice and this permission notice appear in
-- supporting documentation.
--
-- NEIL HODGSON DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
-- INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN
-- NO EVENT SHALL NEIL HODGSON BE LIABLE FOR ANY SPECIAL, INDIRECT OR
-- CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
-- OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
-- NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
-- WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
--
-----------------------------------------------------------------------
-- USAGE
--
-- * Please see SciTELuaExporters.html for notes on how to get this
--   exporter up and running.
-- * Requires SciTE_ExportBase.lua to be loaded first.
-- * Has been tested casually with these lexers: props, lua, cpp,
--   giving byte-for-byte identical output.
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- a simple check to alert of namespace collision, but allows different
-- files to define their own functions in the exporters table
-----------------------------------------------------------------------
if exporters then
  if exporters.SaveToXML then
    error("SciTE_ExporterXML: exporters.SaveToXML already defined")
  end
else
  exporters = {}
end

-----------------------------------------------------------------------
-- exporters:SaveToXML
--
-- Exports the document in the current window to a XML format file.
--
-----------------------------------------------------------------------
function exporters:SaveToXML()
  local selBeg, selEnd = exportutil.GetSelPos()
-- Author: Hans Hagen / PRAGMA ADE / www.pragma-ade.com
-- Version: 1.0 / august 18, 2003
-- Remark: for a suitable style, see ConTeXt (future) distributions
--
-- The idea is that one can use whole files, or ranges of lines in manuals
-- and alike. Since ConTeXt can handle XML files, it's quite convenient to
-- use this format instead of raw TeX, although the output would not look
-- much different in structure.
--
-- We don't put style definitions in here since the main document will in
-- most cases determine the look and feel. This way we have full control over
-- the layout. The type attribute will hold the current lexer value.
--
-- <document>            : the whole thing
-- <data>                : reserved for metadata
-- <text>                : the main bodyof text
-- <line n-'number'>     : a line of text
--
-- <t n='number'>...<t/> : tag
-- <s n='number'/>       : space
-- <g/>                  : >
-- <l/>                  : <
-- <a/>                  : &
-- <h/>                  : #
--
-- We don't use entities, but empty elements for special characters
-- but will eventually use utf-8 (once i know how to get them out).
--
  local XMLDefaultTabSize = 4

  editor:Colourise(0, -1)

  local tabSize = tonumber(props["tabsize"])
  if not tabSize or tabSize == 0 then
    tabSize = XMLDefaultTabSize
  end

  -- local lengthDoc = editor.Length

  local saveName = exportutil.exportfile(props["FileDir"], props["FileName"], "xml")
  local fp = io.open(saveName, "wt")
  if not fp then
    error("exporters:SaveToXML: could not save file \""..saveName.."\"")
  end
  if exportutil.VERBOSE ~= 0 then
    _ALERT("\nExporting to XML, filepath: "..saveName)
  end

  local collapseSpaces = (tonumber(props["export.xml.collapse.spaces"]) or 1) == 1
  local collapseLines = (tonumber(props["export.xml.collapse.lines"]) or 1) == 1

  fp:write("<?xml version='1.0' encoding='ascii'?>\n",
           "<document xmlns='http://www.scintila.org/scite.rng'",
           " filename='", props["FileNameExt"], "'",
           " type='", "unknown", "'",
           " version='", "1.0" ,"'",
           ">\n",
           "<data comment='This element is reserved for future usage.'/>\n",
           "<text>\n")

  local styleCurrent = -1 -- exportutil.StyleAt(0)
  local lineNumber = 1
  local lineIndex = 0
  local styleDone = false
  local lineDone = false
  local charDone = false
  local styleNew = -1
  local spaceLen = 0
  local emptyLines = 0

  local i = selBeg
  while i < selEnd do
    local ch = exportutil.CharAt(i)
    local style = exportutil.StyleAt(i)

    if style ~= styleCurrent then
      styleCurrent = style
      styleNew = style
    end
    if ch == " " then
      spaceLen = spaceLen + 1
    elseif ch == "\t" then
      local ts = tabSize - lineIndex % tabSize
      lineIndex = lineIndex + ts - 1
      spaceLen = spaceLen + ts
    elseif ch == "\f" then
      -- ignore this animal
    elseif ch == "\r" or ch == "\n" then
      if ch == "\r" and exportutil.CharAt(i + 1) == "\n" then
        i = i + 1
      end
      if styleDone then
        fp:write("</t>")
        styleDone = false
      end
      lineIndex = -1
      if lineDone then
        fp:write("</line>\n")
        lineDone = false
      elseif collapseLines then
        emptyLines = emptyLines + 1
      else
        fp:write("<line n='", lineNumber, "'/>\n")
      end
      charDone = false
      lineNumber = lineNumber + 1
      styleCurrent = -1 -- exportutil.StyleAt(i + 1)
    else--ch
      if collapseLines and emptyLines > 0 then
        fp:write("<line/>\n")
      end
      emptyLines = 0
      if not lineDone then
        fp:write("<line n='", lineNumber, "'>")
        lineDone = true
      end
      if styleNew >= 0 then
        if styleDone then fp:write("</t>") end
      end
      if not collapseSpaces then
        while spaceLen > 0 do
          fp:write("<s/>")
          spaceLen = spaceLen - 1
        end
      elseif spaceLen == 1 then
        fp:write("<s/>")
        spaceLen = 0
      elseif spaceLen > 1 then
        fp:write("<s n='", spaceLen, "'/>")
        spaceLen = 0
      end
      if styleNew >= 0 then
        fp:write("<t n='", style, "'>")
        styleNew = -1
        styleDone = true
      end
      if ch == ">" then fp:write("<g/>")
      elseif ch == "<" then fp:write("<l/>")
      elseif ch == "&" then fp:write("<a/>")
      elseif ch == "#" then fp:write("<h/>")
      else fp:write(ch)
      end
      charDone = true
    end--ch
    lineIndex = lineIndex + 1
    i = i + 1
  end--while

  if styleDone then fp:write("</t>") end
  if lineDone then fp:write("</line>\n") end
  if charDone then
    -- no last empty line: fp:write("<line n='", lineNumber, "'/>")
  end
  fp:write("</text>\n",
           "</document>\n")

  fp:close()
  if exportutil.VERBOSE ~= 0 then
    exportutil.progress("... done.")
  end
end

-- end of script
