-----------------------------------------------------------------------
-- Simple functions to get the exporters up and running
-- 20070805
--
-- By Kein-Hong Man <khman@users.sf.net>
-- This script is hereby placed into Public Domain.
--
-----------------------------------------------------------------------

-- *** example; this is in SciTEUser.properties
-- ext.lua.directory=$(SciteDefaultHome)/lua
-- ext.lua.startup.script=$(ext.lua.directory)/SciTEStartup.lua

-----------------------------------------------------------------------
-- example loading function for global scripts
-----------------------------------------------------------------------
function loadscript(scriptfile)
  -- default constants
  local DEFAULTEXT = ".lua"
  local SUBDIR = "/lua"
  -- if relative, find absolute path
  if not string.match(scriptfile, "^%a:[/\\]") then
    local LUAROOT = props["ext.lua.directory"]
    if not LUAROOT then
      local GLOBALROOT = props["SciteDefaultHome"]
      local USERROOT = props["SciteUserHome"]
      LUAROOT = (GLOBALROOT or USERROOT)..SUBDIR
    end
    scriptfile = LUAROOT.."/"..scriptfile
  end
  if not string.match(scriptfile, "\.lua$") then
    scriptfile = scriptfile..DEFAULTEXT
  end
  dofile(scriptfile)
end

-----------------------------------------------------------------------
-- example of loading exporter scripts
-- * unused scripts are commented out to avoid unnecessary loading...
-----------------------------------------------------------------------

-- base library, required by all exporter scripts
loadscript("SciTE_ExportBase.lua")

-- 8-bit charset to UTF-8 conversion for ABW, SXW, ODT
loadscript("SciTE_ExportCharset.lua")
-- *** uncomment if you want the usual Windows character set
--exportutil.CharsetFromSet("windows-1252")

--loadscript("SciTE_ExporterABW.lua")
--CurrentExporter = exporters.SaveToABW
--loadscript("SciTE_ExporterHTML.lua")
--loadscript("SciTE_ExporterHTMLPlus.lua")
--CurrentExporter = exporters.SaveToHTML
-- *** current exporter in use
loadscript("SciTE_ExporterODT.lua")
CurrentExporter = exporters.SaveToODT
--loadscript("SciTE_ExporterPDF.lua")
--loadscript("SciTE_ExporterPDFPlus.lua")
--CurrentExporter = exporters.SaveToPDF
--loadscript("SciTE_ExporterRTF.lua")
--CurrentExporter = exporters.SaveToRTF
--loadscript("SciTE_ExporterSXW.lua")
--CurrentExporter = exporters.SaveToSXW
--loadscript("SciTE_ExporterTeX.lua")
--CurrentExporter = exporters.SaveToTex
--loadscript("SciTE_ExporterXML.lua")
--CurrentExporter = exporters.SaveToXML

-----------------------------------------------------------------------
-- example of key or command binding
-- * use of extman is recommended...
-----------------------------------------------------------------------

scite_Command('Lua-based Exporter|CurrentExporter|Ctrl+5')

-- *** this is in SciTEUser.properties, but extman is much better
-- command.name.5.*=Lua-based Exporter
-- command.subsystem.5.*=3
-- command.5.*=CurrentExporter
-- command.save.before.5.*=2

