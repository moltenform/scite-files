-----------------------------------------------------------------------
-- TeX exporter in Lua for SciTE
-- Version 0.9.6, 20070805
--
-- Adapted from SciTE sources (scite/src/Exporters.cxx CVS 20040723)
-- by Kein-Hong Man <khman@users.sf.net> (This is a straightforward
-- conversion and so I decline to claim it as my own.)
--
-- Copyright 1998-2007 by Neil Hodgson <neilh@scintilla.org>
-- All Rights Reserved
--
-- Permission to use, copy, modify, and distribute this software and
-- its documentation for any purpose and without fee is hereby granted,
-- provided that the above copyright notice appear in all copies and
-- that both that copyright notice and this permission notice appear in
-- supporting documentation.
--
-- NEIL HODGSON DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE,
-- INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS, IN
-- NO EVENT SHALL NEIL HODGSON BE LIABLE FOR ANY SPECIAL, INDIRECT OR
-- CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS
-- OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT,
-- NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION
-- WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.
--
-----------------------------------------------------------------------
-- USAGE
--
-- * Please see SciTELuaExporters.html for notes on how to get this
--   exporter up and running.
-- * Requires SciTE_ExportBase.lua to be loaded first.
-- * Has been tested casually with these lexers: props, lua, bash,
--   perl, python, html, giving byte-for-byte identical output.
-- * With basic text, the lexer does not define "\scitea" but uses it
--   in the body of the TeX file. Is this a bug? This script reproduces
--   the behaviour exactly, but since I don't use the TeX exporter, I
--   cannot say exactly whether it is wrong or right.
-----------------------------------------------------------------------

-----------------------------------------------------------------------
-- a simple check to alert of namespace collision, but allows different
-- files to define their own functions in the exporters table
-----------------------------------------------------------------------
if exporters then
  if exporters.SaveToTex then
    error("SciTE_ExporterTeX: exporters.SaveToTex already defined")
  end
else
  exporters = {}
end

-----------------------------------------------------------------------
-- exporters:SaveToTex
--
-- Exports the document in the current window to a TeX format file.
--
-----------------------------------------------------------------------
function exporters:SaveToTex()
  local selBeg, selEnd = exportutil.GetSelPos()
  local TexDefaultTabSize = 4

  local function getTexRGB(stylecolor)
    -- texcolor[rgb]{0,0.5,0}{....}
    return string.format("%.1f, %.1f, %.1f",
      stylecolor.r / 256, stylecolor.g / 256, stylecolor.b / 256)
  end

  local function texStyle(style)
    local CHARZ = 24    -- 'z' - 'b'
    local buf = ""
    repeat
      buf = buf..string.char(97 + style % CHARZ)
      style = math.floor(style / CHARZ)
    until style == 0
    return buf
  end

  local function defineTexStyle(style, fp, istyle)
    local brackets = 2
    fp:write("\\newcommand{\\scite", texStyle(istyle),
             "}[1]{\\noindent{\\ttfamily{")
    if style.italics then
      fp:write("\\textit{")
      brackets = brackets + 1
    end
    if style.bold then
      fp:write("\\textbf{")
      brackets = brackets + 1
    end
    if style.fore then
      fp:write("\\textcolor[rgb]{", getTexRGB(style.fore), "}{")
      brackets = brackets + 1
    end
    if style.back then
      fp:write("\\colorbox[rgb]{", getTexRGB(style.back), "}{")
      brackets = brackets + 1
    end
    fp:write("#1", string.rep("}", brackets + 1), "\n")
  end

  editor:Colourise(0, -1)
  local tabSize = tonumber(props["tabsize"])
  if not tabSize or tabSize == 0 then
    tabSize = TexDefaultTabSize
  end

  -- local lengthDoc = editor.Length
  local styleIsUsed = {}
  local titleFullPath = tonumber(props["export.tex.title.fullpath"]) or 0

  for i = selBeg, selEnd - 1 do         -- check the used styles
    styleIsUsed[exportutil.StyleAt(i)] = true
  end
  styleIsUsed[exportutil.STYLE_DEFAULT] = true

  local saveName = exportutil.exportfile(props["FileDir"], props["FileName"], "tex")
  local fp = io.open(saveName, "wt")
  if not fp then
    error("exporters:SaveToTex: could not save file \""..saveName.."\"")
  end
  if exportutil.VERBOSE ~= 0 then
    _ALERT("\nExporting to TeX, filepath: "..saveName)
  end

  fp:write([[
\documentclass[a4paper]{article}
\usepackage[a4paper,margin=2cm]{geometry}
\usepackage[T1]{fontenc}
\usepackage{color}
\usepackage{alltt}
\usepackage{times}
]])

  stylemgr:setlexer(editor.Lexer)
  for i = 0, exportutil.STYLE_MAX do    -- get keys
    if styleIsUsed[i] then
      local sd = stylemgr:locate(i)     -- load properties
      if sd.specified ~= "" then
        defineTexStyle(sd, fp, i)       -- writeout style macros
      end
      -- else we should use STYLE_DEFAULT
    end
  end

  fp:write([[
\begin{document}

]])
  fp:write("Source File: ",
    (titleFullPath ~= 0) and props["FilePath"] or props["FileNameExt"],
    "\n\n\\noindent\n\\tiny{\n")

  local styleCurrent = exportutil.StyleAt(0)
  fp:write("\\scite", texStyle(styleCurrent), "{")
  local lineIdx = 0

  local i = selBeg
  while i < selEnd do           -- here process each character of the document
    local ch = exportutil.CharAt(i)
    local style = exportutil.StyleAt(i)

    if style ~= styleCurrent then       -- new style?
      fp:write("}\n\\scite", texStyle(style), "{")
      styleCurrent = style
    end

    if ch == "\t" then  -- write out current character
      local ts = tabSize - lineIdx % tabSize
      lineIdx = lineIdx + ts - 1
      fp:write("\\hspace*{", ts, "em}")
    elseif ch == "\\" then
      fp:write("{\\textbackslash}")
    elseif string.find("><@", ch, 1, 1) then
      fp:write("$", ch, "$")
    elseif string.find("{}^_&$#%~", ch, 1, 1) then
      fp:write("\\", ch)
    elseif string.find("\r\n", ch, 1, 1) then
      lineIdx = -1      -- Because incremented below
      if ch == "\r" and exportutil.CharAt(i + 1) == "\n" then
        i = i + 1       -- Skip the LF
      end
      styleCurrent = exportutil.StyleAt(i + 1)
      fp:write("} \\\\\n\\scite", texStyle(styleCurrent), "{")
    elseif ch == " " then
      if exportutil.CharAt(i + 1) == " " then
        fp:write("{\\hspace*{1em}}")
      else
        fp:write(" ")
      end
    else
      fp:write(ch)
    end--ch
    lineIdx = lineIdx + 1
    i = i + 1
  end--while

  -- close last empty style macros and document too
  fp:write([[
}
} %end tiny

\end{document}
]])
  fp:close()
  if exportutil.VERBOSE ~= 0 then
    exportutil.progress("... done.")
  end
end

-- end of script
