#include <string>

wchar_t* StringFromUTF8(const char *s);
char* UTF8FromString(const std::wstring &s);