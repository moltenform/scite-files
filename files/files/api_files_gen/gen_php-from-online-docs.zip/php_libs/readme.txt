From arjunae's myScite project.

See
https://github.com/arjunae/myScite/tree/devel/contrib/SciTE.apifiles/apiDogs/php_libs
for the latest version

