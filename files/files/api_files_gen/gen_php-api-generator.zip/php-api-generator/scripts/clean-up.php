<?php

echo 'Step 5/5', PHP_EOL,
	'Clean up all mess I have done', PHP_EOL;

foreach(scandir($dir) as $file)
	if($file{0} !== '.')
	{
		unlink( $dir .'/'.$file);
	}

unset( $file );

rmdir( $dir );

unlink( $list );
unlink( $list.'.html' );


echo 'Clean UP Finished OK', PHP_EOL, PHP_EOL;

echo 'End Time: ', date('H:i:s'), PHP_EOL;
