<?php

echo 'Step 4/5', PHP_EOL,
	'I will generate the php-'.$lang.'.api file with all the info I have recollected' .PHP_EOL;

$directory = new DirectoryIterator( $dir );

$fns = array();
$alias = array();

foreach($directory as $file) 
    if(! $file->isDot() )
	{
		$fn = strtr($file->getFilename(), '-', '_');
		
		$html = file_get_contents( $dir .'/'. $file->getFilename() );
		
		$html = html_entity_decode( $html );
		
		$f = array(
			'name' => '',
			'verinfo' => '', 
			'desc' => '', 
			'params' => ''
		);
		
		if( preg_match( '#refname">([^<]+)<#',$html, $match ) == 0 )
		{
			echo 'Skipped function ', $fn, PHP_EOL;
			continue;
		}
		$f['name'] = trim( strtr( $match[1], PHP_EOL, ' '));
		
		preg_match( '#verinfo">([^<]+)<#',$html, $match );
		$f['verinfo'] = trim( strtr( $match[1], PHP_EOL, ' '));
		
		preg_match( '#dc-title">([^<]+)<#',$html, $match );
		$f['desc'] = trim( strtr( $match[1], PHP_EOL, ' ') );
		
		if( substr($f['desc'], 0, strpos($f['desc'], ' ')) == 'Alias')
		{
			preg_match( '#methodname"><a[^>]+>([^<]+)</#',$html, $match );
			$alias[ $fn ] = $match[1];
			continue;
		}
		preg_match( '#dc-description">[^(]+\(([^)]+)\)#',$html, $match );
		$f['params'] = strip_tags( strtr( $match[1], PHP_EOL, ' '));
		
		$f['params'] = preg_replace( '# +(\[?), +#', '$1, ',  $f['params']);
		$f['params'] = preg_replace( '# +\]#', ']',  $f['params']);
		$f['params'] = preg_replace( '#\$ +#', '$',  $f['params']);
		$f['params'] = trim($f['params']);
		 
		preg_match( '#type">([^<]+)<#',$html, $match );
		$f['type'] = trim( strtr( $match[1], PHP_EOL, ' '));
		
		
		$fns[ $f['name'] ] = $f;
    }

unset($f, $match, $html, $file, $directory);

foreach($alias as $al => $fn)
{
	$fns[ $al ] = $fns[ $fn ];

}

ksort( $fns );

foreach($fns as $fn)
	if( !empty($fn['name']) )
		fprintf( $php_api, sprintf("%s (%s) %s %s\t%s".PHP_EOL, $fn['name'], $fn['params'], $fn['type'], $fn['desc'], $fn['verinfo']) );

fclose($php_api);
unset($fns, $fn, $al, $alias, $php_api);
echo 'Finished creating php-'.$lang.'.api', PHP_EOL, PHP_EOL;
