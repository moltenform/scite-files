<?php

set_time_limit(0);
ob_implicit_flush();
ini_set('html_errors', 'Off');

echo 'SciTE php.api File Generator by Martin Scotta <martinscotta@gmail.com>', PHP_EOL ,
	'Feedback, Comments and Bugs are welcome!', PHP_EOL, PHP_EOL;

$langs = array(
	'en' => 'English (Default)',
	'bg' => 'Bulgarian',
	'pt_BR' => 'Brazilian Portuguese',
	'fr' => 'French', 
	'de' => 'German',
	'ja' => 'Japanese',
	'kr' => 'Korean',
	'pl' => 'Polish',
	'ro' => 'Romanian',
	'ru' => 'Russian',
	'es' => 'Spanish',
	'tr' => 'Turkish'
);

if( count($argv) == 1)
{
	echo 'USAGE: php ', $argv[0], ' [lang] ', PHP_EOL , PHP_EOL ,
		"lang:", PHP_EOL;
	
	foreach($langs as $lang => $desc)
		echo "\t", $lang, ': ', $desc, PHP_EOL;
	
	exit;
}

$lang = isset($argv[1]) && array_key_exists($argv[1], $langs) ? $argv[1] : 'en';
$list = 'fn-'.$lang.'.list';
$dir = 'fn-'.$lang;

echo 'Using Language: ', $langs[ $lang ], PHP_EOL;

unset($langs);
echo 'This process can take hours, depending on your internet connection, so, please be pattient', PHP_EOL ,
	 'Start Time: ', date('M-d H:i:s'), PHP_EOL ,
	 'Current Directory is :', getcwd(), PHP_EOL, PHP_EOL;


