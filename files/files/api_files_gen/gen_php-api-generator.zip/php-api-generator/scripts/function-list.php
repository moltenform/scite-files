<?php

echo 'Step 2/5', PHP_EOL;

if( file_exists( $list.'.html' ))
{
	echo 'Using "'. $list .'.html" file from previously run' . PHP_EOL;
	
	$html = file_get_contents($list.'.html');
	
}
else
{
	echo 
		'Fetch the function list from php.net', PHP_EOL,
		'This ussualy takes a little, maybe php.net issue?', PHP_EOL;
	
	if( ($html = file_get_contents( 'http://www.php.net/manual/'.$lang.'/indexes.php' )) === '')
		exit( 
			'Unable to download function list from php.net' . PHP_EOL . 
			'Check your Internet Connection' . PHP_EOL 
		);
	
	echo 'Download Complete', PHP_EOL;
	file_put_contents($list.'.html', $html);
}

echo 'Searching the functions in the HTML', PHP_EOL;

preg_match_all( '#function\.([^\.]+)\.php#', $html, $match);
unset( $html );

if( count($match) !== 2 )
{
	exit( 
		'There was a problem finding the functions'. PHP_EOL .
		'Please check http://www.php.net/manual/'.$lang.'/indexes.php'. PHP_EOL
	);
}

echo 'Founded '.count($match[1]).' functions in the HTML', PHP_EOL . 
	'Lets write them into ' . $list . PHP_EOL;

foreach($match[1] as $fn)
{
	fprintf($fn_list, '%s'.PHP_EOL, $fn );

} unset( $match, $fn );


fclose( $fn_list );
unset( $fn_list );

echo 'Wrote OK!', PHP_EOL , PHP_EOL;

