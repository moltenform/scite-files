<?php



echo 'Step 1/5', PHP_EOL, 
	'Let\'s do some checks and cleanups...', PHP_EOL;

if( version_compare( PHP_VERSION, '5.2.0', '<=') )
{
	exit( 
		'This script is intented to be runned at least with PHP 5.2.0' . PHP_EOL .
		'You have ' . PHP_VERSION . PHP_EOL 
	);
}

if( !is_writable( '.' ))
	exit( 'I need write permision in the current directory' );

# fn-lang.list file
if( ($fn_list = fopen($list, 'w')) === false )
{
	exit( 
		'I need an empty file called "'. $list .'" in the current directory with permisition to write in it' . PHP_EOL
	);
}

# php.api file
if( ($php_api = fopen( 'php-'.$lang.'.api', 'w')) === false )
{
	exit( 
		'I need an empty file called "php.api" in the current directory with permisition to write in it' . PHP_EOL
	);
}
	
# fn-lang dir
if( !is_dir($dir) )
{
	if( mkdir($dir, 0777 ) == false)
		exit( 'I need a directory called "' . $dir . '" in the current directory with permisition to write in it'. PHP_EOL );
}

if( !is_writable($dir) )
{
	exit( 'I need a directory called "' . $dir . '" in the current directory with permisition to write in it' . PHP_EOL );
}

echo 'All checks Done!', PHP_EOL, PHP_EOL; 
