<?

echo 'Step 3/5', PHP_EOL,
	'This is the longest step', PHP_EOL,
	'I will download the manual page for each function in "fn.list"', PHP_EOL;

$all = explode( PHP_EOL, file_get_contents( $list ));

$i=0;
$c=count($all);
foreach($all  as $fn)
{
	++$i;
	
	if( $fn )
	{
		if( file_exists( $dir .'/'. $fn ))
			continue;
		
		echo sprintf('%2.2f', round( $i / $c, 4) * 100), '% Downloading ', 
			 $url = 'http://www.php.net/manual/'.$lang.'/function.'. $fn .'.php', PHP_EOL;
		$html = file_get_contents( $url );
		
		file_put_contents( $dir .'/'. $fn, $html);
		
		unset( $url, $html );
	}
} unset($i, $c, $fn, $all);

echo 'I have all manual page for each function', PHP_EOL, PHP_EOL;

?>