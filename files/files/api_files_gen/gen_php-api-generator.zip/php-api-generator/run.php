<?php

if( PHP_SAPI !== 'cli' )
{
	exit( 'This script is intented to be runned in a shell script' );
}



include 'scripts/usage.php';
include 'scripts/check.php';
include 'scripts/function-list.php';
include 'scripts/find-reference.php';
include 'scripts/make-api.php';
include 'scripts/clean-up.php';



