parrot.properties and hll_parrot.properties.
created by Sekou Diao. (sekou dot diao at gmail dot com).

This properties files have been tested with parrot 0.8.2 and SciTE 1.7 for windows.
It uses the python lexer to parse PIR an PASM source code.

To add parrot to SciTE put parrot.properties and hll_parrot.properties in your SciTE folder
and add "import parrot".


TODO
- Add Unix support.
- Add custom parrot lexer.
- Add more HLLs as they will be available
