http://code.google.com/p/scite-files/wiki/Customization_SciteForWindowsScripters
(Saved from http://dev.remotenetworktechnology.com/SciTE/index.htm )
Scripts by Alex K. Angelopoulos


Ben F:
To use a .properties file, say x.properties for example, move the file into the SciTE directory,
and open Scite. From Options menu click on SciTEGlobal.properties.
Search in this file for 'import all the lang' and you will see a list like
import ada
import asm.
Add a line for 
import x
and save your changes.

Rename the .vbs.txt files to .vbs to use them.

