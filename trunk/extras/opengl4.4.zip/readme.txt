OpenGL 4.4 API file for SciTE.

API file contains only glext functions and can be used with other opengl api files (i.e. api.*.c=opengl.api;glext.api).

Nikita Kindt
