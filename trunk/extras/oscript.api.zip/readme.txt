The API files contain functions and constants built-in to the OScript language and objects (with their methods and properties) provided by Livelink core ospaces. There are three files available; you can imagine the difference by looking at the screenshot tooltip-samples.png. Autocomplete support is the same with any of the three files.

The installation can be done by unpacking the files to $(SciteDefaultHome)/api, choosing one of them and renaming it to oscript.api. (The file name oscript.api is referenced from the file oscript.properties delivered with SciTE.)

oscript-prototypes.api - single line with the prototype of a method or the type of a property
oscript-brief.api - the prototype from oscript-prototypes.api with a few words or sentences of description
oscript-detailed.api - the prototype and description from oscript-brief.api with details about method parameters and return value

