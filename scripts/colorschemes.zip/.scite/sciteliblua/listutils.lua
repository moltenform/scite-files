-- @encoding: UTF-8
-- @author Marko Mahnič
-- @date 2007-11-27

module("listutils", package.seeall)

-- @author Marko Mahnič
-- @date 2007-11-30
-- Remove all occurences of item (list[i] == item) from the list.
function remove_item(list, item)
   if list == nil or item == nil 
   then return end
   
   local modified = true
   while modified do
      modified = false
      for i,v in ipairs(list) do
         if v == item then
            table.remove(list, i)
            modified = true
            break
         end
      end
   end
end

-- @author Marko Mahnič
-- @date 2007-11-27
-- Insert an item in a LRU (Least Recently Used) list.
-- Duplicate items are removed. The number of items is 
-- limited to maxitems when specified and greater than 0.
function lru_insert(list, value, maxitems)
   if list == nil or value == nil 
   then return end
   
   local modified = true
   while modified do
      modified = false
      for i,v in ipairs(list) do
         if v == value then
            table.remove(list, i)
            modified = true
            break
         end
      end
   end
   table.insert(list, 1, value)
   if maxitems ~= nil and maxitems > 0 then
      while #list > maxitems do table.remove(list) end
   end
end

-- @author Marko Mahnič
-- @date 2007-11-30
-- Create a list of items from list that are not in subtract.
-- An item is in subtract when list[i] == subtract[j].
function listutils.difference(list, subtract)
   local diff = {}
   local found
   for i,v in ipairs(list) do
      found = false
      for j,vs in ipairs(subtract) do
         if vs == v then found = true; break end
      end
      if not found then table.insert(diff, v) end
   end
   return diff
end
