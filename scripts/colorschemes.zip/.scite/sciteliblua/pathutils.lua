-- @encoding: UTF-8
-- @author Marko Mahnič
-- @date 2007-11-27

require("osutils")

module("pathutils", package.seeall)

-- @author Marko Mahnič
function concat(path, filename)
   path = path:gsub(osutils.pathsepre .. "+$", "")
   filename = filename:gsub("^" .. osutils.pathsepre .. "+", "")
   return path .. osutils.pathsep .. filename
end

