-- @encoding: UTF-8
-- 200711-24 Marko Mahnič
-- 
-- Instead of calling require("wx") the scripts should 
-- use require("scitewx") to preserve some global objects.
-- WARNING: 
--      (scite)wx should be loaded in the startup script. 
--      If it is loaded from a command, the global environment "wx"
--      is lost upon command completion and the command
--      will not work any more.
-- WARNING: 
--      wx will use 14Mb of memory just to load (on Windows).
--      SciTe without wx uses around 5 Mb of memory.
--      SciTe with wx uses around 19 Mb of memory.
-- WARNING:
--      To use wxLua with SciTE you need to use a proxy DLL
--      that maps the calls to lua into scite.exe
--      When using the default lua5.1.dll that comes with wxLua
--      the widgets can still be created, but there are some limitations.
--      For example when you try to fill the list of a combobox by passing
--      a lua table into wxComboBox constructor, the dropdown list
--      is always empty.

require ("sciteutils")

local old = sciteutils.save_environment()
require("wx")
sciteutils.restore_environment(old)

-- Returns the WindowID of the SciTE window. This ID cannot be used in wx
-- since it would have to be wrapped by a wxWindow, but I know of no
-- function that would take a HANDLE and create a wxWindow* 
-- (wrapped in userdata).
function GetSciteWindowId()
   local id = tonumber(props["WindowID"])
   -- local app = wx.wxGetApp()
   -- local topw = app:GetTopWindow() -- it's nil until the first window is created
   if id == nil then id = wx.NULL end
   -- print (id, app, topw)
   return id
end
