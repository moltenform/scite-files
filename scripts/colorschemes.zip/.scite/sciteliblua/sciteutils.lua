-- @encoding: UTF-8
-- @author Marko Mahnič
-- @date 2007-11-27

local ENV = _G

module("sciteutils", package.seeall)

-- @author Marko Mahnič
-- Save the current environment before requiring a module that
-- modifies global identifiers. The environment can then restored
-- restore_environment (usu. right aftrer the call to require).
-- @exmple:
--      -- wx modifies print so that it displays a message box
--      -- but we want it to print to the output pane
--      local old = save_environment()
--      require("wx") 
--      restore_environment(old)
function save_environment()
   local gnames = {
         "print", "error", "trace", "_ALERT", "dostring",
         "scite", "editor", "output", "props"
         }
   local old = {}
   for k,v in pairs(gnames) do
      old[v] = ENV[v]
   end
   return old
end

-- @author Marko Mahnič
function restore_environment(old)
   for k,v in pairs(old) do
      if old[k] ~= nil and old[k] ~= ENV[k] then 
         ENV[k] = old[k]
      end
   end
end
