-- @encoding: UTF-8
-- @author Marko Mahnič
-- @date 2007-11-27

module("fileutils", package.seeall)

function exists(fname)
  local f = io.open(fname)
  if not f then return false
  else
    f:close()
    return true
  end
end
