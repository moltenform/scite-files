-- 2007-11-24 mmarko
-- This is the main script that is loaded when SciTe starts up.
-- It is placed in the global SciTe Lua library where common
-- function libraries are placed.
-- The global Lua library could be placed in "$SciteDefaultHome/lua"
-- and can be set with "ext.lua.library" property.
--
-- At the end of this script, a local user startup script is executed
-- if it exists. The user startup script should load user specific
-- libraries.
-- The local Lua library could be placed in "$SciteUserHome/.scite/lua"
-- and can be set with "ext.lua.userlib" property.

local function path_append(v)
   -- the following tests are not exactly correct -- see osutils.lua
   local PLAT_GTK = props["PLAT_GTK"] ~= ""
   local PLAT_WIN = props["PLAT_WIN"] ~= ""
   if v ~= nil and v ~= "" then
      local a1, a2
      if PLAT_WIN then
         v = string.gsub(v, "/", "\\")
         a1, a2 = "\\?", "\\?.lua"
      else
         v = string.gsub(v, "\\", "/")
         a1, a2 = "/?", "/?.lua"
      end
      if nil == string.find(package.path, v..a1..";") then
         package.path=package.path..";"..v..a1
      end
      if nil == string.find(package.path, v..a2..";") then
         package.path=package.path..";"..v..a2
      end
   end
end
path_append(props["ext.lua.library"])
path_append(props["ext.lua.userlib"])

require ('osutils')
require ('extman')
require ('fileutils')

-- Load the user startup file
-- This file should be loaded after all the desired files from the global library are loaded
local userstartup=props["SciteUserHome"].."/.scite/lua/sciteuser.lua"
if props["ext.lua.userlib"] ~= nil then
   userstartup=props["ext.lua.userlib"].."/sciteuser.lua"
end

if fileutils.exists(userstartup) then
   dofile(userstartup)
end
