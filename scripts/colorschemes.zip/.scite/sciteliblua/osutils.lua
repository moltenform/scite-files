module ("osutils", package.seeall)

-- There should be TWO settings
--      OS: WINDOWS/LINUX/OSX - access to the system (files, processes, ...)
--              OS_WIN, OS_LINUX, OS_OSX
--      UI: GTK/WINGUI - visual subsystem (fonts, device contexts, ...)
--              GUI_GTK, GUI_WIN
--
-- Currently there is only PLAT_WIN and PLAT_GTK:
local PLAT_GTK = props["PLAT_GTK"] ~= ""
local PLAT_WIN = props["PLAT_WIN"] ~= ""

if PLAT_WIN then
   OS = "windows"
   GUI = "wingui"
   if PLAT_GTK then 
      GUI = "gtk"
      -- print("Platform is not well defined (GTK & WIN)")
   end
elseif PLAT_GTK then 
   OS = "unix"
   GUI = "gtk"
end

if OS == "windows" then
   pathsep = "\\"
   pathsepre = "\\\\"
else
   pathsep = "/"
   pathsepre = "\\/"
end
