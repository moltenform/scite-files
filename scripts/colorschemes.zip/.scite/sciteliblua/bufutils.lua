-- @encoding: UTF-8
-- @author Marko Mahnič
-- @date 2007-11-27

require("listutils")

module("bufutils", package.seeall)

-- maybe this shuld be in editutils
function looking_at(pattern, flags, pos)
   if pattern == nil then return false end
   if flags == nil then flags = 0 end
   if pos == nil then pos = editor.CurrentPos end
   -- how can this be optimized ?
   local s,e = editor:findtext(pattern, flags, pos)
   return s == pos
end

local recent_files = {}
local recent_buffers = {}
local max_recent_files = 30 -- setting, eg.: scite.recent.files.max

-- A new buffer is open. Add to LRU list of files and buffers.
function register_open_buffer(filename)
   if filename == nil then return end
   listutils.lru_insert(recent_files, filename, max_recent_files)
   listutils.lru_insert(recent_buffers, filename, nil)
end

-- The buffer we switch to becomes the LRU buffer.
-- The previously used buffer is at position 2 in the list.
function register_switch_buffer(filename)
   if filename ~= nil then
      listutils.lru_insert(recent_buffers, filename, nil)
   end
end

-- When a file is closed it becomes first in file LRU.
-- It is also removed from the buffer list.
function register_close_buffer(filename)
   if filename == nil then return end
   listutils.lru_insert(recent_files, filename, max_recent_files)
   listutils.remove_item(recent_buffers, filename)
end

-- Set the list of recent files.
-- Used to restore state from previous session.
function set_recent_file_list(list)
   if list == nil then recent_files = {}
   else recent_files = list
   end
end

-- Get the full list of recent files
-- Used to save the session state to a state file.
function get_recent_file_list()
   return recent_files
end

-- Get the list of loaded buffers (in LRU order)
function get_recent_buffer_list()
   return recent_buffers
end

-- Get a list of recent files that are not currently open.
function get_recent_closed_file_list()
   return listutils.difference(recent_files, recent_buffers)
end
