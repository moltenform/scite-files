AMPL
A Modeling Language
for Mathematical Programming

Refer to the paper
LEE & RAFFENSPERGER -- USING AMPL FOR TEACHING THE TSP
accessible from
http://archive.ite.journal.informs.org/Vol7No1/LeeRaffensperger/

which describes how to set up a SciTE environment.
4.2. Scite configuration files for AMPL.