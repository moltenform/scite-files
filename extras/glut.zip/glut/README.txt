[2006/12/15]
This api should be used with OpenGl api avaliable on scite web site
Nelson Bilber Rodrigues [i020574@dei.isep.ipp.pt]