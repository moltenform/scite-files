Maurizio Butti, Wed, 09 May 2007 01:34:00 -0700

I've written a small utility that generates an "api" file for C# 
extracting classes and methods names from the system asssemblies.

